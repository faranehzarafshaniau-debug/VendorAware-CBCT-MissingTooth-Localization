from __future__ import annotations

import torch
from torch import nn
from torch.utils.checkpoint import checkpoint


class _GRL(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x, scale):
        ctx.scale = scale
        return x.view_as(x)

    @staticmethod
    def backward(ctx, grad):
        return -ctx.scale * grad, None


class Block(nn.Module):
    def __init__(self, cin, cout, stride=1):
        super().__init__()
        self.c1 = nn.Conv3d(cin, cout, 3, stride=stride, padding=1, bias=False)
        self.n1 = nn.GroupNorm(min(8, cout), cout)
        self.c2 = nn.Conv3d(cout, cout, 3, padding=1, bias=False)
        self.n2 = nn.GroupNorm(min(8, cout), cout)
        self.skip = nn.Identity() if cin == cout and stride == 1 else nn.Conv3d(cin, cout, 1, stride=stride, bias=False)
        self.act = nn.SiLU(inplace=False)

    def forward(self, x):
        identity = self.skip(x)
        x = self.act(self.n1(self.c1(x)))
        return self.act(self.n2(self.c2(x)) + identity)


class VRSSL3D(nn.Module):
    def __init__(self, base=24, fpn=48, regions=4, vendors=3, checkpointing=True):
        super().__init__(); self.checkpointing = checkpointing
        self.stem = nn.Sequential(nn.Conv3d(1, base, 3, stride=2, padding=1, bias=False),
                                  nn.GroupNorm(min(8, base), base), nn.SiLU(inplace=False))
        ch = [base, base*2, base*4, base*8]
        self.stages = nn.ModuleList([
            nn.Sequential(Block(ch[0], ch[0]), Block(ch[0], ch[0])),
            nn.Sequential(Block(ch[0], ch[1], 2), Block(ch[1], ch[1])),
            nn.Sequential(Block(ch[1], ch[2], 2), Block(ch[2], ch[2])),
            nn.Sequential(Block(ch[2], ch[3], 2), Block(ch[3], ch[3]))])
        self.lateral = nn.ModuleList([nn.Conv3d(c, fpn, 1) for c in ch])
        self.smooth = nn.ModuleList([nn.Conv3d(fpn, fpn, 3, padding=1) for _ in ch])
        self.objectness = nn.ModuleList([nn.Conv3d(fpn, 1, 3, padding=1) for _ in ch])
        self.box = nn.ModuleList([nn.Conv3d(fpn, 6, 3, padding=1) for _ in ch])
        self.region = nn.ModuleList([nn.Conv3d(fpn, regions, 3, padding=1) for _ in ch])
        self.vendor = nn.Sequential(nn.Linear(fpn*4, 256), nn.SiLU(), nn.Dropout(0.2), nn.Linear(256, vendors))

    def _run(self, module, x):
        if self.checkpointing and self.training and x.requires_grad:
            return checkpoint(module, x, use_reentrant=False)
        return module(x)

    def forward(self, x, grl_scale=0.0):
        x = self.stem(x); feats = []
        for stage in self.stages:
            x = self._run(stage, x); feats.append(x)
        p = [None]*4; p[3] = self.lateral[3](feats[3])
        for i in (2,1,0):
            p[i] = self.lateral[i](feats[i]) + torch.nn.functional.interpolate(p[i+1], size=feats[i].shape[-3:], mode='trilinear', align_corners=False)
        p = [self.smooth[i](p[i]) for i in range(4)]
        outputs, pooled = [], []
        for i, z in enumerate(p):
            outputs.append((self.objectness[i](z), self.box[i](z), self.region[i](z)))
            pooled.append(torch.nn.functional.adaptive_avg_pool3d(z, 1).flatten(1))
        feature = torch.cat(pooled, dim=1)
        vendor = self.vendor(_GRL.apply(feature, float(grl_scale)))
        return outputs, vendor
