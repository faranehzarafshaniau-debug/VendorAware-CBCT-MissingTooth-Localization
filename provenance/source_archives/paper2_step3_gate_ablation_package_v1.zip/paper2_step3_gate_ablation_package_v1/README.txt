PAPER 2 STEP 3 -- GATE ABLATION AND PSEUDO-LABEL QUALITY
========================================================

Purpose
-------
This post-lock exploratory package tests the mechanism of the pseudo-label gate
without reopening calibration or outer-test partitions.

Cumulative regimes
------------------
1. confidence_only: object and class confidence thresholds.
2. confidence_uncertainty: confidence plus object/box predictive variance.
3. full_gate: confidence plus uncertainty plus multi-view geometric/class
   stability. Existing checksum-verified full-gate checkpoints are reused.

Formal workload
---------------
- 10 new training runs: two new regimes x five folds.
- 15 validation-only pseudo-label quality evaluations.
- Five object-confidence operating points: 0.50--0.90.
- Metrics: pseudo precision, target coverage, FP/volume, matched-box IoU,
  physical center error, region accuracy, and downstream validation pFROC.

Scientific guardrails
---------------------
- Only optimization, unlabeled, and validation data are used.
- Calibration and outer-test access are prohibited.
- The analysis is labelled post-lock exploratory.
- Fold-level exact sign-flip inference treats the five folds as independent
  blocks; repeated cells or patches are not treated as patient-level samples.

Install and smoke test
----------------------
unzip -o paper2_step3_gate_ablation_package_v1.zip
cd paper2_step3_gate_ablation_package_v1
sha256sum -c PACKAGE_SHA256SUMS.txt
cd ..
bash paper2_step3_gate_ablation_package_v1/scripts/run_step3_smoke_v1.sh \
  |& tee logs/step3_gate_ablation_smoke_v1.log

Formal run
----------
nohup bash paper2_step3_gate_ablation_package_v1/scripts/run_step3_full_v1.sh \
  > logs/step3_gate_ablation_full_v1.log 2>&1 &
echo $! | tee logs/step3_gate_ablation_full_v1.pid
