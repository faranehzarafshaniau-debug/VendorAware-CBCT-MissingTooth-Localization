#!/usr/bin/env python3
from pathlib import Path
import copy, yaml

ROOT = Path(__file__).resolve().parents[2]
SRC = ROOT / "paper2_reliable_gated_vrssl3d_package_v1" / "configs"
OUT = Path(__file__).resolve().parents[1] / "configs"
OUT.mkdir(parents=True, exist_ok=True)

regimes = {
    "confidence_only": {
        "training_regime": "confidence_only_gate_ablation",
        "use_uncertainty_gate": False,
        "use_geometric_stability_gate": False,
        "teacher_views": [{"intensity_scale": 1.0, "shift_zyx": [0, 0, 0]}],
    },
    "confidence_uncertainty": {
        "training_regime": "confidence_plus_uncertainty_gate_ablation",
        "use_uncertainty_gate": True,
        "use_geometric_stability_gate": False,
        "teacher_views": [
            {"intensity_scale": 1.0, "shift_zyx": [0, 0, 0]},
            {"intensity_scale": 0.95, "shift_zyx": [0, 0, 0]},
            {"intensity_scale": 1.05, "shift_zyx": [0, 0, 0]},
        ],
    },
    "full_gate": {
        "training_regime": "confidence_plus_uncertainty_plus_geometric_stability",
        "use_uncertainty_gate": True,
        "use_geometric_stability_gate": True,
    },
}

for fold in range(5):
    source = SRC / f"fold{fold}_full_reliable_gated_vrssl3d_v1.yaml"
    cfg = yaml.safe_load(source.read_text())
    for name, changes in regimes.items():
        item = copy.deepcopy(cfg); item.update(copy.deepcopy(changes))
        item["version"] = f"step3_{name}_fold{fold}_v1"
        item["normalization_stats_path"] = f"outputs/fold{fold}_pure_supervised_v1/normalization_stats_pure_supervised_v1.json"
        item["precision_coverage_confidences"] = [0.50, 0.60, 0.70, 0.80, 0.90]
        (OUT / f"{name}_fold{fold}_v1.yaml").write_text(yaml.safe_dump(item, sort_keys=False))

for name in ("confidence_only", "confidence_uncertainty"):
    item = yaml.safe_load((OUT / f"{name}_fold0_v1.yaml").read_text())
    item["version"] += "_smoke"; item["epochs"] = 1; item["steps_per_epoch"] = 2
    item["validation_every_epochs"] = 1; item["precision_coverage_max_cases"] = 1
    (OUT / f"{name}_fold0_v1_smoke.yaml").write_text(yaml.safe_dump(item, sort_keys=False))

print("STEP3 CONFIGS: PASS (17 files)")
