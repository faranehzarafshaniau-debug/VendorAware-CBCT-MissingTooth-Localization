#!/usr/bin/env bash
set -euo pipefail
cd /mnt/morph-cbct-data/PAPER2_LOCALIZATION_CANONICAL
source .venv/bin/activate
export PYTHONPATH="$PWD/paper2_step3_gate_ablation_package_v1/src"
python paper2_step3_gate_ablation_package_v1/scripts/prepare_step3_configs_v1.py
mkdir -p logs
for regime in confidence_only confidence_uncertainty; do
  out="outputs/step3_${regime}_fold0_v1_smoke"
  mkdir -p "$out"
  cp outputs/fold0_pure_supervised_v1/normalization_stats_pure_supervised_v1.json "$out/normalization_stats_v2.json"
  python paper2_step3_gate_ablation_package_v1/scripts/train_gate_ablation_v1.py \
    --project-root "$PWD" \
    --config "paper2_step3_gate_ablation_package_v1/configs/${regime}_fold0_v1_smoke.yaml" \
    --initial-checkpoint outputs/fold0_pure_supervised_v1/checkpoint_best.pt \
    --output-dir "$out"
  python paper2_step3_gate_ablation_package_v1/scripts/evaluate_pseudo_precision_coverage_v1.py \
    --project-root "$PWD" \
    --config "paper2_step3_gate_ablation_package_v1/configs/${regime}_fold0_v1_smoke.yaml" \
    --checkpoint "$out/checkpoint_best.pt" \
    --output "outputs/step3_pseudo_quality_smoke_v1/${regime}_fold0_v1.json"
done
echo "STEP3 GATE ABLATION SMOKE: PASS"
