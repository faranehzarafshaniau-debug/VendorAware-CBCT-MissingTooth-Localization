#!/usr/bin/env python3
from pathlib import Path
import csv, hashlib, itertools, json, statistics
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "outputs" / "step3_gate_ablation_summary_v1"
OUT.mkdir(parents=True, exist_ok=True)


def digest(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(4 * 1024 * 1024), b""):
            h.update(b)
    return h.hexdigest()


def signflip_p(deltas):
    observed = abs(sum(deltas) / len(deltas))
    values = []
    for signs in itertools.product((-1, 1), repeat=len(deltas)):
        values.append(abs(sum(s * d for s, d in zip(signs, deltas)) / len(deltas)))
    return sum(v >= observed - 1e-15 for v in values) / len(values)


def quality_auc(curve):
    points = sorted((float(x["target_coverage"]), float(x["pseudo_precision"])) for x in curve)
    if len(points) < 2:
        return 0.0
    return float(np.trapezoid([p[1] for p in points], [p[0] for p in points]))


regimes = ["confidence_only", "confidence_uncertainty", "full_gate"]
rows = []
for fold in range(5):
    for regime in regimes:
        if regime == "full_gate":
            report_path = ROOT / f"outputs/fold{fold}_full_reliable_gated_vrssl3d_v1/reliable_gated_vrssl3d_report_v1.json"
        else:
            report_path = ROOT / f"outputs/step3_{regime}_fold{fold}_v1/gate_ablation_report_v1.json"
        quality_path = ROOT / f"outputs/step3_pseudo_quality_v1/{regime}_fold{fold}_v1.json"
        report = json.loads(report_path.read_text()); quality = json.loads(quality_path.read_text())
        if report.get("calibration_accessed") or report.get("outer_test_accessed"):
            raise RuntimeError(f"Forbidden access flag in {report_path}")
        if quality.get("calibration_accessed") or quality.get("outer_test_accessed") or not quality.get("validation_only"):
            raise RuntimeError(f"Invalid quality scope in {quality_path}")
        selected = min(quality["precision_coverage_curve"], key=lambda x: abs(float(x["object_confidence"]) - 0.70))
        rows.append({
            "fold": fold, "regime": regime, "best_validation_pfroc": float(report["best_validation_partial_froc"]),
            "pseudo_precision_at_0_70": float(selected["pseudo_precision"]), "target_coverage_at_0_70": float(selected["target_coverage"]),
            "fp_per_volume_at_0_70": float(selected["fp_per_volume"]), "median_iou_at_0_70": selected["median_iou"],
            "median_center_error_mm_at_0_70": selected["median_center_error_mm"],
            "region_accuracy_at_0_70": selected["region_accuracy_on_matches"], "precision_coverage_auc": quality_auc(quality["precision_coverage_curve"]),
        })

methods = {}
for regime in regimes:
    rr = [r for r in rows if r["regime"] == regime]; vals = [r["best_validation_pfroc"] for r in rr]
    methods[regime] = {
        "n_folds": 5, "mean_pfroc": statistics.mean(vals), "sd_pfroc": statistics.stdev(vals),
        "mean_pseudo_precision_at_0_70": statistics.mean(r["pseudo_precision_at_0_70"] for r in rr),
        "mean_target_coverage_at_0_70": statistics.mean(r["target_coverage_at_0_70"] for r in rr),
        "mean_precision_coverage_auc": statistics.mean(r["precision_coverage_auc"] for r in rr),
    }

comparisons = {}
for a, b in zip(regimes[1:], regimes[:-1]):
    av = [r["best_validation_pfroc"] for r in rows if r["regime"] == a]
    bv = [r["best_validation_pfroc"] for r in rows if r["regime"] == b]
    delta = [x - y for x, y in zip(av, bv)]
    comparisons[f"{a}_minus_{b}"] = {"fold_deltas": delta, "mean_delta": statistics.mean(delta), "exact_fold_blocked_signflip_p": signflip_p(delta)}

summary = {
    "status": "PASS", "post_lock_exploratory": True, "formal_training_runs_new": 10,
    "full_gate_folds_reused": 5, "pseudo_quality_evaluations": 15,
    "calibration_accessed": False, "outer_test_accessed": False,
    "methods": methods, "comparisons": comparisons, "fold_results": rows,
}
json_path = OUT / "step3_gate_ablation_summary_v1.json"; csv_path = OUT / "step3_gate_ablation_folds_v1.csv"
json_path.write_text(json.dumps(summary, indent=2))
with csv_path.open("w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)
checksum = OUT / "STEP3_GATE_ABLATION_SHA256SUMS.txt"
checksum.write_text(f"{digest(json_path)}  {json_path.name}\n{digest(csv_path)}  {csv_path.name}\n")
print(json.dumps(summary, indent=2)); print("STEP3 GATE ABLATION AUDIT: PASS")
