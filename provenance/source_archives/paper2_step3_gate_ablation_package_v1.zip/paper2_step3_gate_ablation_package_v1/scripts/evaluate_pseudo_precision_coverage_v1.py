#!/usr/bin/env python3
from __future__ import annotations

import argparse, csv, hashlib, importlib.util, json, sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
import yaml

from vrssl3d_train.model import VRSSL3D


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(4 * 1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def validation_rows(manifest, fold):
    with open(manifest, newline="", encoding="utf-8") as f:
        rows = [r for r in csv.DictReader(f) if int(r["outer_test_fold"]) == fold]
    selected = [r for r in rows if r["role"] == "validation"]
    if len(selected) != 10:
        raise RuntimeError(f"Expected 10 validation cases, found {len(selected)}")
    forbidden = [r for r in selected if r["role"] in {"calibration", "outer_test"}]
    if forbidden:
        raise RuntimeError("Forbidden partition access")
    return selected


def shifted_view(x, shift_zyx):
    shift = tuple(int(v) for v in shift_zyx)
    y = torch.zeros_like(x)
    src, dst = [], []
    for n, s in zip(x.shape[-3:], shift):
        if s >= 0:
            src.append(slice(0, n - s)); dst.append(slice(s, n))
        else:
            src.append(slice(-s, n)); dst.append(slice(0, n + s))
    y[(..., *dst)] = x[(..., *src)]
    return y


def align_output(outputs, shift_zyx, input_shape):
    obj, box, cls = outputs[0]
    grid = np.asarray(obj.shape[-3:])
    stride = np.asarray(input_shape) / grid
    cell_shift = np.rint(np.asarray(shift_zyx) / stride).astype(int)
    if not np.allclose(cell_shift * stride, shift_zyx, atol=1e-6):
        raise ValueError("Teacher shift is not aligned to the P2 stride")
    aligned = [torch.roll(t, tuple(-int(x) for x in cell_shift), (-3, -2, -1)) for t in (obj, box, cls)]
    valid = torch.ones_like(aligned[0], dtype=torch.bool)
    for axis, s in zip((-3, -2, -1), cell_shift):
        s = int(s)
        if s > 0:
            valid.narrow(axis, valid.shape[axis] - s, s).zero_()
        elif s < 0:
            valid.narrow(axis, 0, -s).zero_()
    return tuple(aligned), valid


def ensemble_tensors(model, patch, views, shape):
    x = torch.from_numpy(patch[None, None]).float().cuda()
    outputs, valids = [], []
    with torch.no_grad():
        for view in views:
            scale = float(view["intensity_scale"])
            shift = tuple(int(v) for v in view["shift_zyx"])
            transformed = shifted_view(x * scale, shift)
            with torch.autocast("cuda", dtype=torch.float16):
                pred, _ = model(transformed, 0.0)
            aligned, valid = align_output(pred, shift, shape)
            outputs.append(aligned); valids.append(valid)
    obj = torch.stack([torch.sigmoid(o[0]).float() for o in outputs])
    box = torch.stack([o[1].float() for o in outputs])
    cls = torch.stack([F.softmax(o[2].float(), dim=1) for o in outputs])
    cls_mean = cls.mean(0)
    cls_conf, cls_idx = cls_mean.max(1, keepdim=True)
    votes = torch.stack([x.argmax(1, keepdim=True) for x in cls])
    return {
        "obj_mean": obj.mean(0),
        "obj_var": obj.var(0, unbiased=False),
        "box_mean": box.mean(0),
        "box_var": box.var(0, unbiased=False).mean(1, keepdim=True),
        "cls_conf": cls_conf,
        "cls_idx": cls_idx,
        "agreement": (votes == votes[0:1]).all(0),
        "valid": torch.stack(valids).all(0),
    }


def decode_selected(tensors, start_zyx, shape, volume_shape, cfg, confidence):
    gate = (tensors["obj_mean"] >= confidence) & (tensors["cls_conf"] >= float(cfg["pseudo_class_confidence"])) & tensors["valid"]
    if bool(cfg.get("use_uncertainty_gate", False)):
        gate &= (tensors["obj_var"] <= float(cfg["pseudo_variance_max"]))
        gate &= (tensors["box_var"] <= float(cfg["pseudo_box_variance_max"]))
    if bool(cfg.get("use_geometric_stability_gate", False)):
        gate &= tensors["agreement"]
    flat_gate = gate.flatten()
    scores = (tensors["obj_mean"] * tensors["cls_conf"]).flatten()
    idx = torch.where(flat_gate)[0]
    keep = int(cfg["pseudo_max_cells_per_patch"])
    if idx.numel() > keep:
        idx = idx[torch.topk(scores[idx], keep).indices]
    obj = tensors["obj_mean"][0, 0]
    box = tensors["box_mean"][0]
    cls = tensors["cls_idx"][0, 0]
    grid = np.asarray(obj.shape)
    stride_zyx = np.asarray(shape, float) / grid
    stride_xyz = stride_zyx[::-1]
    candidates = []
    for flat in idx.tolist():
        z, y, x = np.unravel_index(flat, tuple(grid))
        raw = box[:, z, y, x]
        offset_xyz = torch.sigmoid(raw[:3]).cpu().numpy()
        extent_xyz = torch.exp(raw[3:].clamp(-4, 6)).cpu().numpy() * stride_xyz
        center_xyz = np.asarray(start_zyx[::-1], float) + (np.asarray([x, y, z]) + offset_xyz) * stride_xyz
        lo = np.maximum(center_xyz - extent_xyz / 2, 0)
        hi = np.minimum(center_xyz + extent_xyz / 2, np.asarray(volume_shape[::-1], float) - 1)
        if np.any(hi <= lo):
            continue
        candidates.append({
            "box_xyz": np.r_[lo, hi].tolist(),
            "score": float(scores[flat].item()),
            "region_index": int(cls[z, y, x].item()),
        })
    return candidates


def iou_xyz(a, b):
    a, b = np.asarray(a, float), np.asarray(b, float)
    inter = np.maximum(np.minimum(a[3:], b[3:]) - np.maximum(a[:3], b[:3]), 0)
    iv = float(np.prod(inter)); av = float(np.prod(np.maximum(a[3:] - a[:3], 0))); bv = float(np.prod(np.maximum(b[3:] - b[:3], 0)))
    return iv / max(av + bv - iv, 1e-12)


def quality(predictions, ground_truth, affine, match_iou):
    used = set(); matched_iou, errors, class_ok = [], [], []
    predictions = sorted(predictions, key=lambda x: x["score"], reverse=True)
    for pred in predictions:
        choices = [(iou_xyz(pred["box_xyz"], gt["box_xyz"]), j) for j, gt in enumerate(ground_truth) if j not in used]
        if not choices:
            continue
        best_iou, j = max(choices)
        if best_iou < match_iou:
            continue
        used.add(j); gt = ground_truth[j]; matched_iou.append(best_iou)
        center = (np.asarray(pred["box_xyz"][:3]) + np.asarray(pred["box_xyz"][3:])) / 2
        pred_lps = (affine @ np.r_[center, 1])[:3]
        errors.append(float(np.linalg.norm(pred_lps - np.asarray(gt["center_lps"]))))
        class_ok.append(int(pred["region_index"] == gt["region_index"]))
    tp = len(used); fp = len(predictions) - tp; fn = len(ground_truth) - tp
    return tp, fp, fn, matched_iou, errors, class_ok


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--project-root", type=Path, required=True)
    ap.add_argument("--config", type=Path, required=True)
    ap.add_argument("--checkpoint", type=Path, required=True)
    ap.add_argument("--output", type=Path, required=True)
    args = ap.parse_args()
    root = args.project_root.resolve(); cfg = yaml.safe_load(args.config.read_text())
    if "outer_test" in str(args.output).lower() or "calibration" in str(args.output).lower():
        raise RuntimeError("Output name violates the development-only guard")
    manifest = root / "manifests/inner_split_v1/nested_partitions_v1.csv"
    rows = validation_rows(manifest, int(cfg["outer_fold"]))
    if cfg.get("precision_coverage_max_cases") is not None:
        rows = rows[:int(cfg["precision_coverage_max_cases"])]
    base = load_module("pilot_base", root / "paper2_fold0_pilot_package/scripts/train_fold0_pilot.py")
    inf = load_module("inference_base", root / "paper2_fold0_inference_package/scripts/infer_fold0_outer_test.py")
    stats = json.loads((root / cfg["normalization_stats_path"]).read_text())
    cache = root / "outputs/preprocessed_v1"; shape = list(map(int, cfg["patch_dhw"])); stride = list(map(int, cfg["stride_dhw"]))
    model = VRSSL3D().cuda().eval(); ckpt = torch.load(args.checkpoint, map_location="cpu", weights_only=False)
    model.load_state_dict(ckpt.get("teacher", ckpt["student"]))
    levels = [float(x) for x in cfg["precision_coverage_confidences"]]
    totals = {x: {"tp": 0, "fp": 0, "fn": 0, "ious": [], "errors": [], "class_ok": [], "cases": 0} for x in levels}
    with torch.no_grad():
        for row in rows:
            volume, meta = base.load_case(cache, row); by_level = {x: [] for x in levels}
            for z in inf.starts(volume.shape[0], shape[0], stride[0]):
                for y in inf.starts(volume.shape[1], shape[1], stride[1]):
                    for x in inf.starts(volume.shape[2], shape[2], stride[2]):
                        patch = base.norm(inf.crop_at(volume, (z, y, x), shape), stats)
                        tensors = ensemble_tensors(model, patch, cfg["teacher_views"], shape)
                        for level in levels:
                            by_level[level].extend(decode_selected(tensors, (z, y, x), shape, volume.shape, cfg, level))
            gts = [{"box_xyz": b["aabb_xyz_voxel"], "center_lps": b["center_lps_mm"], "region_index": int(b["region_code"][1:]) - 1} for b in meta["boxes"]]
            affine = np.asarray(meta["target_affine_xyz_to_lps"], float)
            for level in levels:
                preds = inf.nms(by_level[level], float(cfg["nms_iou"]), int(cfg["maximum_detections_per_case"]))
                tp, fp, fn, ious, errors, class_ok = quality(preds, gts, affine, float(cfg["matching_iou"]))
                t = totals[level]; t["tp"] += tp; t["fp"] += fp; t["fn"] += fn; t["ious"] += ious; t["errors"] += errors; t["class_ok"] += class_ok; t["cases"] += 1
    curve = []
    for level in levels:
        t = totals[level]; tp, fp, fn = t["tp"], t["fp"], t["fn"]
        curve.append({
            "object_confidence": level, "pseudo_precision": tp / max(tp + fp, 1), "target_coverage": tp / max(tp + fn, 1),
            "fp_per_volume": fp / max(t["cases"], 1), "tp": tp, "fp": fp, "fn": fn,
            "median_iou": float(np.median(t["ious"])) if t["ious"] else None,
            "median_center_error_mm": float(np.median(t["errors"])) if t["errors"] else None,
            "region_accuracy_on_matches": float(np.mean(t["class_ok"])) if t["class_ok"] else None,
        })
    report = {
        "status": "PASS", "post_lock_exploratory": True, "validation_only": True,
        "calibration_accessed": False, "outer_test_accessed": False, "regime": cfg["training_regime"],
        "fold": int(cfg["outer_fold"]), "validation_cases": len(rows), "checkpoint_sha256": sha256(args.checkpoint),
        "manifest_sha256": sha256(manifest), "precision_coverage_curve": curve,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True); args.output.write_text(json.dumps(report, indent=2))
    print(json.dumps(report, indent=2)); print("STEP3 PSEUDO PRECISION-COVERAGE: PASS")


if __name__ == "__main__":
    main()
