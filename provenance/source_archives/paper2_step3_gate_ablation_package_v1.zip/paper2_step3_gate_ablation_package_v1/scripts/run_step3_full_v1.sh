#!/usr/bin/env bash
set -euo pipefail
cd /mnt/morph-cbct-data/PAPER2_LOCALIZATION_CANONICAL
source .venv/bin/activate
export PYTHONPATH="$PWD/paper2_step3_gate_ablation_package_v1/src"
python paper2_step3_gate_ablation_package_v1/scripts/prepare_step3_configs_v1.py
mkdir -p logs outputs/step3_pseudo_quality_v1

for fold in 0 1 2 3 4; do
  for regime in confidence_only confidence_uncertainty; do
    out="outputs/step3_${regime}_fold${fold}_v1"
    mkdir -p "$out"
    if test ! -f "$out/normalization_stats_v2.json"; then
      cp "outputs/fold${fold}_pure_supervised_v1/normalization_stats_pure_supervised_v1.json" "$out/normalization_stats_v2.json"
    fi
    echo "===== STEP3 ${regime} FOLD ${fold} START $(date -Is) ====="
    python paper2_step3_gate_ablation_package_v1/scripts/train_gate_ablation_v1.py \
      --project-root "$PWD" \
      --config "paper2_step3_gate_ablation_package_v1/configs/${regime}_fold${fold}_v1.yaml" \
      --initial-checkpoint "outputs/fold${fold}_pure_supervised_v1/checkpoint_best.pt" \
      --output-dir "$out"
    echo "===== STEP3 ${regime} FOLD ${fold} PASS $(date -Is) ====="
  done
done

for fold in 0 1 2 3 4; do
  for regime in confidence_only confidence_uncertainty full_gate; do
    if test "$regime" = full_gate; then
      checkpoint="outputs/fold${fold}_full_reliable_gated_vrssl3d_v1/checkpoint_best.pt"
    else
      checkpoint="outputs/step3_${regime}_fold${fold}_v1/checkpoint_best.pt"
    fi
    echo "===== STEP3 QUALITY ${regime} FOLD ${fold} START $(date -Is) ====="
    python paper2_step3_gate_ablation_package_v1/scripts/evaluate_pseudo_precision_coverage_v1.py \
      --project-root "$PWD" \
      --config "paper2_step3_gate_ablation_package_v1/configs/${regime}_fold${fold}_v1.yaml" \
      --checkpoint "$checkpoint" \
      --output "outputs/step3_pseudo_quality_v1/${regime}_fold${fold}_v1.json"
    echo "===== STEP3 QUALITY ${regime} FOLD ${fold} PASS $(date -Is) ====="
  done
done

python paper2_step3_gate_ablation_package_v1/scripts/audit_and_summarize_step3_v1.py
echo "===== STEP3 ALL TRAINING AND QUALITY ANALYSES PASS $(date -Is) ====="
