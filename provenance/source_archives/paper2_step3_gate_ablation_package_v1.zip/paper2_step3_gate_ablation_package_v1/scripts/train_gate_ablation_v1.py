#!/usr/bin/env python3
from __future__ import annotations

import argparse, copy, csv, hashlib, importlib.util, json, random, sys, time
from pathlib import Path
import numpy as np
import torch
import torch.nn.functional as F
import yaml

from vrssl3d_train.model import VRSSL3D

VENDOR={'Kavo':0,'Meyer':1,'Newtom':2}

def rows_for_fold(path,fold):
    with open(path,newline='',encoding='utf-8') as f:
        rows=[r for r in csv.DictReader(f) if int(r['outer_test_fold'])==fold]
    roles={k:[r for r in rows if r['role']==k] for k in ('optimization','validation','calibration','outer_test')}
    actual={k:len(v) for k,v in roles.items()}
    valid=actual in ({'optimization':46,'validation':10,'calibration':10,'outer_test':17},{'optimization':47,'validation':10,'calibration':10,'outer_test':16})
    if not valid: raise RuntimeError(f'Fold role mismatch: {actual}')
    return roles

def load_module(name,path):
    spec=importlib.util.spec_from_file_location(name,path); mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod

def digest(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(4*1024*1024),b''): h.update(b)
    return h.hexdigest()

def crop_start(v,start,shape):
    start=np.asarray(start,int); shape=np.asarray(shape,int); end=start+shape
    lo=np.maximum(start,0); hi=np.minimum(end,np.asarray(v.shape)); dlo=lo-start; dhi=dlo+(hi-lo)
    out=np.full(tuple(shape),float(np.min(v)),np.float32)
    out[tuple(slice(a,b) for a,b in zip(dlo,dhi))]=np.asarray(v[tuple(slice(a,b) for a,b in zip(lo,hi))],np.float32)
    return out,start

def diverse_positive(base,cache,row,shape,stats,rng):
    v,m=base.load_case(cache,row); b=rng.choice(m['boxes']); a=np.asarray(b['aabb_xyz_voxel'],float); center_zyx=((a[:3]+a[3:])/2)[::-1]
    margin=np.minimum(np.asarray(shape)*0.15,24); desired=rng.uniform(margin,np.asarray(shape)-margin); start=np.rint(center_zyx-desired).astype(int)
    x,start=crop_start(v,start,shape); return base.norm(x,stats),start,m

def random_negative(base,cache,row,shape,stats,rng):
    v,m=base.load_case(cache,row); maxstart=np.maximum(np.asarray(v.shape)-np.asarray(shape),0); start=np.array([rng.integers(0,x+1) for x in maxstart]); x,start=crop_start(v,start,shape)
    empty={'boxes':[]}; return base.norm(x,stats),start,empty,m

def candidate_score(model,x):
    with torch.no_grad(),torch.autocast('cuda',dtype=torch.float16): out,_=model(torch.from_numpy(x[None,None]).float().cuda(),0.0)
    return float(torch.sigmoid(out[0][0]).max())

def hard_negative(base,model,cache,row,shape,stats,rng,n):
    candidates=[random_negative(base,cache,row,shape,stats,rng) for _ in range(n)]
    scores=[candidate_score(model,c[0]) for c in candidates]; return candidates[int(np.argmax(scores))]

def shifted_view(x,shift_zyx):
    """Translate a 3-D patch without circular wrap and return a validity mask."""
    shift=tuple(int(v) for v in shift_zyx); y=torch.zeros_like(x); valid=torch.zeros_like(x,dtype=torch.bool)
    src=[]; dst=[]
    for n,s in zip(x.shape[-3:],shift):
        if s>=0: src.append(slice(0,n-s)); dst.append(slice(s,n))
        else: src.append(slice(-s,n)); dst.append(slice(0,n+s))
    y[(...,*dst)]=x[(...,*src)]; valid[(...,*dst)]=True
    return y,valid

def align_teacher_output(outputs,shift_zyx,input_shape):
    """Map a translated teacher prediction back to the unshifted P2 grid."""
    obj,box,cls=outputs[0]; grid=np.asarray(obj.shape[-3:]); stride=np.asarray(input_shape)/grid
    cell_shift=np.rint(np.asarray(shift_zyx)/stride).astype(int)
    if not np.allclose(cell_shift*stride,np.asarray(shift_zyx),atol=1e-6):
        raise ValueError(f'Geometric shift {shift_zyx} must align with output stride {stride.tolist()}')
    aligned=[]
    for tensor in (obj,box,cls):
        z,y,x=(int(v) for v in cell_shift)
        aligned.append(torch.roll(tensor,shifts=(-z,-y,-x),dims=(-3,-2,-1)))
    valid=torch.ones_like(aligned[0],dtype=torch.bool)
    z,y,x=(int(v) for v in cell_shift)
    for axis,s in zip((-3,-2,-1),(z,y,x)):
        if s>0: valid.narrow(axis,valid.shape[axis]-s,s).zero_()
        elif s<0: valid.narrow(axis,0,-s).zero_()
    return [tuple(aligned)],valid

def validation_froc(base,inf,model,cache,rows,shape,stride,stats,cfg):
    model.eval(); cases=[]
    with torch.no_grad():
        for row in rows:
            v,m=base.load_case(cache,row); cand=[]
            for z in inf.starts(v.shape[0],shape[0],stride[0]):
                for y in inf.starts(v.shape[1],shape[1],stride[1]):
                    for x in inf.starts(v.shape[2],shape[2],stride[2]):
                        p=base.norm(inf.crop_at(v,(z,y,x),shape),stats); t=torch.from_numpy(p[None,None]).float().cuda()
                        with torch.autocast('cuda',dtype=torch.float16): outputs,_=model(t,0.0)
                        cand.extend(inf.decode_patch(outputs,(z,y,x),shape,v.shape,int(cfg['per_patch_topk']),float(cfg['minimum_candidate_score'])))
            preds=inf.nms(cand,float(cfg['nms_iou']),int(cfg['maximum_detections_per_case'])); affine=np.asarray(m['target_affine_xyz_to_lps'])
            for p in preds:
                box=np.asarray(p['box_xyz']); p['center_lps']=inf.lps(affine,(box[:3]+box[3:])/2).tolist()
            gts=[]
            for b in m['boxes']:
                a=np.asarray(b['aabb_xyz_voxel']); gts.append({'box_xyz':a.tolist(),'center_lps':b['center_lps_mm'],'region_index':int(b['region_code'][1:])-1})
            cases.append({'predictions':preds,'ground_truth':gts})
    scores=sorted({0.0,1.0,*[round(p['score'],6) for c in cases for p in c['predictions']]}); total=sum(len(c['ground_truth']) for c in cases); curve=[]
    for th in scores:
        tp=fp=fn=0; errors=[]
        for c in cases:
            a,b,d,e=inf.match_case(c['predictions'],c['ground_truth'],th,float(cfg['matching_iou'])); tp+=a; fp+=b; fn+=d; errors+=e
        curve.append({'threshold':th,'sensitivity':tp/max(total,1),'fp_per_volume':fp/len(cases),'tp':tp,'fp':fp,'fn':fn,'median_center_error_mm':float(np.median(errors)) if errors else None})
    points=[]
    for budget in cfg['froc_budgets']:
        eligible=[x for x in curve if x['fp_per_volume']<=float(budget)]; best=max(eligible,key=lambda x:(x['sensitivity'],-x['fp_per_volume']))
        points.append({'budget':float(budget),**best})
    return {'partial_froc_score':float(np.mean([x['sensitivity'] for x in points])),'budget_points':points,'ground_truth_objects':total,'curve':curve}

def gated_pseudo_consistency(student_outputs, teacher_outputs, valid_masks, cfg):
    t_obj=torch.stack([torch.sigmoid(o[0][0]).float() for o in teacher_outputs])
    t_box=torch.stack([o[0][1].float() for o in teacher_outputs])
    t_cls=torch.stack([F.softmax(o[0][2].float(),dim=1) for o in teacher_outputs])
    obj_mean=t_obj.mean(0); obj_var=t_obj.var(0,unbiased=False)
    box_mean=t_box.mean(0); box_var=t_box.var(0,unbiased=False).mean(1,keepdim=True)
    cls_mean=t_cls.mean(0); cls_conf,cls_index=cls_mean.max(1,keepdim=True)
    cls_votes=torch.stack([x.argmax(1,keepdim=True) for x in t_cls]); agreement=(cls_votes==cls_votes[0:1]).all(0)
    valid=torch.stack(valid_masks).all(0)
    gate=(obj_mean>=float(cfg['pseudo_confidence']))&(cls_conf>=float(cfg['pseudo_class_confidence']))&valid
    if bool(cfg.get('use_uncertainty_gate',False)):
        gate=gate&(obj_var<=float(cfg['pseudo_variance_max']))&(box_var<=float(cfg['pseudo_box_variance_max']))
    if bool(cfg.get('use_geometric_stability_gate',False)):
        gate=gate&agreement
    flat_score=obj_mean.flatten(); flat_gate=gate.flatten(); accepted=int(flat_gate.sum())
    max_keep=int(cfg['pseudo_max_cells_per_patch'])
    if accepted>max_keep:
        eligible=torch.where(flat_gate,flat_score,torch.full_like(flat_score,-1)); idx=torch.topk(eligible,max_keep).indices
        flat_gate.zero_(); flat_gate[idx]=True; gate=flat_gate.reshape_as(gate); accepted=max_keep
    s_obj=torch.sigmoid(student_outputs[0][0]).float(); s_box=student_outputs[0][1].float(); s_cls=student_outputs[0][2].float()
    if not gate.any(): return s_obj.sum()*0,0,{'objectness':0.0,'box':0.0,'class':0.0}
    mask=gate.expand_as(s_obj); l_obj=F.mse_loss(s_obj[mask],obj_mean[mask])
    box_mask=gate.expand(-1,s_box.shape[1],-1,-1,-1); l_box=F.smooth_l1_loss(s_box[box_mask],box_mean[box_mask])
    cls_mask=gate.expand(-1,s_cls.shape[1],-1,-1,-1); l_cls=F.kl_div(F.log_softmax(s_cls,dim=1)[cls_mask],cls_mean[cls_mask],reduction='batchmean')
    return l_obj+0.5*l_box+0.5*l_cls,accepted,{'objectness':float(l_obj.detach()),'box':float(l_box.detach()),'class':float(l_cls.detach())}

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--project-root',type=Path,required=True); ap.add_argument('--config',type=Path,required=True); ap.add_argument('--output-dir',type=Path,required=True); ap.add_argument('--initial-checkpoint',type=Path); args=ap.parse_args()
    root=args.project_root.resolve(); out=args.output_dir.resolve(); out.mkdir(parents=True,exist_ok=True); cfg=yaml.safe_load(args.config.read_text());
    base=load_module('pilot_base',root/'paper2_fold0_pilot_package/scripts/train_fold0_pilot.py'); inf=load_module('inference_base',root/'paper2_fold0_inference_package/scripts/infer_fold0_outer_test.py')
    seed=int(cfg['seed']); random.seed(seed); np.random.seed(seed); torch.manual_seed(seed); torch.cuda.manual_seed_all(seed); rng=np.random.default_rng(seed)
    manifest=root/'manifests/inner_split_v1/nested_partitions_v1.csv'; roles=rows_for_fold(manifest,int(cfg['outer_fold']))
    with open(root/'manifests/split_v1/eligible_unlabeled_v1.csv',newline='',encoding='utf-8') as f: unlabeled=list(csv.DictReader(f))
    cache=root/'outputs/preprocessed_v1'; stats_path=out/'normalization_stats_v2.json'
    if stats_path.exists(): stats=json.loads(stats_path.read_text())
    else:
        stats=base.fit_stats(cache,roles['optimization'],unlabeled,cfg,rng); stats['optimization_case_ids']=[r['case_id'] for r in roles['optimization']]; stats['unlabeled_case_ids']=[r['case_id'] for r in unlabeled]; stats_path.write_text(json.dumps(stats,indent=2),encoding='utf-8')
    shape=list(map(int,cfg['patch_dhw'])); stride=list(map(int,cfg['stride_dhw'])); student=VRSSL3D().cuda(); teacher=copy.deepcopy(student).eval()
    for p in teacher.parameters(): p.requires_grad_(False)
    opt=torch.optim.AdamW(student.parameters(),lr=float(cfg['learning_rate']),weight_decay=float(cfg['weight_decay'])); scaler=torch.amp.GradScaler('cuda',init_scale=float(cfg['amp_initial_scale']),growth_interval=1000)
    best=-1.0; history=[]; start_epoch=0; last=out/'checkpoint_last.pt'
    if last.exists():
        c=torch.load(last,map_location='cpu',weights_only=False); student.load_state_dict(c['student']); teacher.load_state_dict(c['teacher']); opt.load_state_dict(c['optimizer']); scaler.load_state_dict(c['scaler']); best=c['best']; history=c['history']; start_epoch=c['epoch']+1
        for group in opt.param_groups:
            group['lr']=float(cfg['learning_rate']); group['weight_decay']=float(cfg['weight_decay'])
        if not (out/'checkpoint_best.pt').exists(): torch.save(c,out/'checkpoint_best.pt')
        print(f'RESUME epoch={start_epoch}',flush=True)
    elif args.initial_checkpoint:
        c=torch.load(args.initial_checkpoint,map_location='cpu',weights_only=False)
        student.load_state_dict(c['student']); teacher.load_state_dict(c.get('teacher',c['student']))
        print(f'INITIALIZED_FROM={args.initial_checkpoint} source_epoch={c.get("epoch")}',flush=True)
    for epoch in range(start_epoch,int(cfg['epochs'])):
        student.train(); epoch_losses=[]; pos_count=neg_count=accepted=0; consistency_parts=[]; t0=time.time(); torch.cuda.reset_peak_memory_stats()
        for step in range(int(cfg['steps_per_epoch'])):
            lr=base.pick_vendor_balanced(roles['optimization'],step,rng); ur=base.pick_vendor_balanced(unlabeled,step+1,rng); positive=rng.random()<float(cfg['positive_fraction'])
            if positive: x,xstart,xmeta=diverse_positive(base,cache,lr,shape,stats,rng); pos_count+=1
            else:
                if epoch>=int(cfg['hard_negative_start_epoch']): x,xstart,xmeta,_=hard_negative(base,teacher,cache,lr,shape,stats,rng,int(cfg['hard_negative_candidates']))
                else: x,xstart,xmeta,_=random_negative(base,cache,lr,shape,stats,rng)
                neg_count+=1
            u,_,_,_=random_negative(base,cache,ur,shape,stats,rng); xt=torch.from_numpy(x[None,None]).float().cuda(); ut=torch.from_numpy(u[None,None]).float().cuda(); opt.zero_grad(set_to_none=True)
            with torch.autocast('cuda',dtype=torch.float16): pred,vlog=student(xt,float(cfg['grl_scale'])); lsup,_=base.targets_and_loss(pred,xmeta,xstart,shape); lv=F.cross_entropy(vlog.float(),torch.tensor([VENDOR[lr['device']]],device='cuda'))
            scaler.scale(lsup+float(cfg['vendor_loss_weight'])*lv).backward(); teacher_outputs=[]; valid_masks=[]
            with torch.no_grad():
                for view in cfg['teacher_views']:
                    scale=float(view['intensity_scale']); shift=tuple(int(v) for v in view['shift_zyx'])
                    transformed,_=shifted_view(ut*scale,shift)
                    with torch.autocast('cuda',dtype=torch.float16): tout,_=teacher(transformed,0.0)
                    aligned,valid=align_teacher_output(tout,shift,shape); teacher_outputs.append(aligned); valid_masks.append(valid)
            with torch.autocast('cuda',dtype=torch.float16): up,uv=student(ut,float(cfg['grl_scale'])); luv=F.cross_entropy(uv.float(),torch.tensor([VENDOR[ur['device']]],device='cuda'))
            lc,naccept,cparts=gated_pseudo_consistency(up,teacher_outputs,valid_masks,cfg); accepted+=naccept; consistency_parts.append(cparts)
            ramp=max(0.0,min(1.0,(epoch-int(cfg['ssl_ramp_start_epoch'])+1)/max(int(cfg['ssl_ramp_epochs']),1))); current_cw=float(cfg['consistency_loss_weight'])*ramp
            scaler.scale(current_cw*lc+float(cfg['vendor_loss_weight'])*luv).backward(); scaler.unscale_(opt); gn=torch.nn.utils.clip_grad_norm_(student.parameters(),float(cfg['gradient_clip']))
            if not torch.isfinite(gn): raise RuntimeError(f'Nonfinite gradient epoch={epoch} step={step}')
            scaler.step(opt); scaler.update(); base.ema(teacher,student,float(cfg['ema_momentum'])); epoch_losses.append(float(lsup.detach()))
        do_val=((epoch+1)%int(cfg['validation_every_epochs'])==0 or epoch==int(cfg['epochs'])-1); vf=None
        if do_val: vf=validation_froc(base,inf,teacher,cache,roles['validation'],shape,stride,stats,cfg); score=vf['partial_froc_score']
        else: score=None
        rec={'epoch':epoch,'train_supervised_loss':float(np.mean(epoch_losses)),'positive_steps':pos_count,'negative_steps':neg_count,'accepted_pseudo_cells':accepted,'consistency_weight':current_cw,'mean_consistency_parts':{k:float(np.mean([x[k] for x in consistency_parts])) for k in ('objectness','box','class')},'validation_partial_froc':score,'validation_budget_points':vf['budget_points'] if vf else None,'seconds':time.time()-t0,'peak_reserved_gb':torch.cuda.max_memory_reserved()/1024**3}; history.append(rec); print(json.dumps(rec),flush=True)
        state={'epoch':epoch,'student':student.state_dict(),'teacher':teacher.state_dict(),'optimizer':opt.state_dict(),'scaler':scaler.state_dict(),'best':best,'history':history,'config':cfg,'manifest_sha256':digest(manifest),'normalization_sha256':digest(stats_path)}
        if score is not None and score>best: best=score; state['best']=best; torch.save(state,out/'checkpoint_best.pt')
        state['best']=best; torch.save(state,last); (out/'history_v2.json').write_text(json.dumps(history,indent=2),encoding='utf-8')
    report={'status':'PASS','training_regime':cfg['training_regime'],'post_lock_exploratory':True,'version':cfg['version'],'outer_fold':cfg['outer_fold'],'seed':seed,'epochs_completed':len(history),'best_validation_partial_froc':best,'optimization_cases':len(roles['optimization']),'validation_cases':len(roles['validation']),'unlabeled_cases':len(unlabeled),'initial_checkpoint':str(args.initial_checkpoint) if args.initial_checkpoint else None,'gates':{'use_uncertainty_gate':bool(cfg.get('use_uncertainty_gate',False)),'use_geometric_stability_gate':bool(cfg.get('use_geometric_stability_gate',False)),'object_confidence':cfg['pseudo_confidence'],'object_variance':cfg['pseudo_variance_max'],'class_confidence':cfg['pseudo_class_confidence'],'box_variance':cfg['pseudo_box_variance_max'],'geometric_views':cfg['teacher_views']},'calibration_accessed':False,'outer_test_accessed':False,'history':history}
    rp=out/'gate_ablation_report_v1.json'; rp.write_text(json.dumps(report,indent=2),encoding='utf-8'); files=[rp,out/'history_v2.json',stats_path,out/'checkpoint_best.pt']; (out/'GATE_ABLATION_SHA256SUMS.txt').write_text(''.join(f'{digest(p)}  {p.name}\n' for p in files),encoding='utf-8'); print(json.dumps(report,indent=2)); print('STEP3 GATE ABLATION: PASS')

if __name__=='__main__': main()
