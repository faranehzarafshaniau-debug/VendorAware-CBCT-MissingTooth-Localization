Fold-0 pilot training v1

Trains VR-SSL3D for 10 pilot epochs using only the locked optimization role
plus the eligible unlabeled pool. Normalization statistics are fit once from
those training inputs. Validation is used for checkpoint selection.
Calibration and outer-test data are not opened. The run is resumable from
checkpoint_last.pt and writes checksummed learning history and best checkpoint.

This pilot establishes optimization behavior. Outer-test localization metrics
are generated only after the pilot checkpoint and settings are accepted.
