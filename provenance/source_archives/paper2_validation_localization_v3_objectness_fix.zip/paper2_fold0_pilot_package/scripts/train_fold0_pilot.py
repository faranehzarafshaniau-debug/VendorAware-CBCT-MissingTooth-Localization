#!/usr/bin/env python3
from __future__ import annotations

import argparse, copy, csv, hashlib, json, math, random, time
from pathlib import Path
import numpy as np
import torch
import torch.nn.functional as F
import yaml

from vrssl3d_train.model import VRSSL3D

VENDOR={'Kavo':0,'Meyer':1,'Newtom':2}

def digest(p):
    h=hashlib.sha256();
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(4*1024*1024),b''): h.update(b)
    return h.hexdigest()

def rows_for_fold(path,fold):
    with open(path,newline='',encoding='utf-8') as f: rows=[r for r in csv.DictReader(f) if int(r['outer_test_fold'])==fold]
    roles={k:[r for r in rows if r['role']==k] for k in ('optimization','validation','calibration','outer_test')}
    expected={'optimization':46,'validation':10,'calibration':10,'outer_test':17}
    if {k:len(v) for k,v in roles.items()}!=expected: raise RuntimeError(f'Fold role mismatch: { {k:len(v) for k,v in roles.items()} }')
    return roles

def load_case(cache,row):
    d=cache/row['device']/row['case_id']; v=np.load(d/'volume_resampled_float16.npy',mmap_mode='r')
    m=json.loads((d/'metadata.json').read_text(encoding='utf-8')); return v,m

def fit_stats(cache,optimization,unlabeled,cfg,rng):
    samples=[]; n=int(cfg['normalization_voxels_per_case'])
    for row in optimization+unlabeled:
        v,_=load_case(cache,row); flat=v.reshape(-1); idx=rng.integers(0,len(flat),size=min(n,len(flat)))
        samples.append(np.asarray(flat[idx],dtype=np.float32))
    x=np.concatenate(samples); q=cfg['normalization_percentiles']; lo,hi=np.percentile(x,q)
    x=np.clip(x,lo,hi); return {'p_low':float(lo),'p_high':float(hi),'mean':float(x.mean()),'std':float(x.std()),
                                  'fit_cases':len(optimization)+len(unlabeled),'sampled_voxels':int(len(x))}

def crop(v,center_xyz,shape_dhw):
    shape=np.asarray(shape_dhw); c=np.asarray(center_xyz[::-1]); start=np.rint(c-shape/2).astype(int); end=start+shape
    lo=np.maximum(start,0); hi=np.minimum(end,np.asarray(v.shape)); dlo=lo-start; dhi=dlo+(hi-lo)
    out=np.full(tuple(shape),float(np.min(v)),np.float32)
    out[tuple(slice(a,b) for a,b in zip(dlo,dhi))]=np.asarray(v[tuple(slice(a,b) for a,b in zip(lo,hi))],np.float32)
    return out,start

def norm(x,s): return ((np.clip(x,s['p_low'],s['p_high'])-s['mean'])/max(s['std'],1e-6)).astype(np.float32)

def positive_patch(cache,row,shape,stats,rng):
    v,m=load_case(cache,row); box=rng.choice(m['boxes']); a=np.asarray(box['aabb_xyz_voxel'],float); center=(a[:3]+a[3:])/2
    jitter=rng.uniform(-8,8,size=3); x,start=crop(v,center+jitter,shape); return norm(x,stats),start,m

def random_patch(cache,row,shape,stats,rng):
    v,m=load_case(cache,row); center=rng.uniform(np.asarray(shape[::-1])/2,np.maximum(np.asarray(v.shape[::-1])-np.asarray(shape[::-1])/2,np.asarray(shape[::-1])/2))
    x,start=crop(v,center,shape); return norm(x,stats),start,m

def targets_and_loss(outputs,meta,start_zyx,shape_dhw):
    obj,reg,cls=outputs[0]; grid=np.asarray(obj.shape[-3:]); stride=np.asarray(shape_dhw)/grid
    tobj=torch.zeros_like(obj); box_losses=[]; class_logits=[]; class_targets=[]; positives=0
    for b in meta['boxes']:
        a=np.asarray(b['aabb_xyz_voxel'],float); cxyz=(a[:3]+a[3:])/2; exyz=a[3:]-a[:3]
        local_zyx=cxyz[::-1]-start_zyx
        if np.any(local_zyx<0) or np.any(local_zyx>=np.asarray(shape_dhw)): continue
        cell=np.floor(local_zyx/stride).astype(int); tobj[0,0,cell[0],cell[1],cell[2]]=1
        pred=reg[0,:,cell[0],cell[1],cell[2]].float(); cell_xyz=cell[::-1].astype(float); stride_xyz=stride[::-1]
        offset=cxyz-(start_zyx[::-1])-cell_xyz*stride_xyz; offset=offset/stride_xyz
        target=torch.tensor(np.r_[offset,np.log(np.maximum(exyz/stride_xyz,1e-3))],device=obj.device,dtype=torch.float32)
        decoded=torch.cat([torch.sigmoid(pred[:3]),pred[3:]])
        box_losses.append(F.smooth_l1_loss(decoded,target)); class_logits.append(cls[0,:,cell[0],cell[1],cell[2]].float()); class_targets.append(int(b['region_code'][1:])-1); positives+=1
    prob=torch.sigmoid(obj.float()); ce=F.binary_cross_entropy_with_logits(obj.float(),tobj.float(),reduction='none')
    positive=tobj.bool(); negative=~positive; pt=torch.where(positive,prob,1-prob); focal=(1-pt).pow(2)*ce
    # Do not average one foreground cell into hundreds of thousands of background
    # cells. Normalize foreground independently and use only the hardest negatives.
    lpos=focal[positive].mean() if positive.any() else obj.float().sum()*0
    neg_values=focal[negative].flatten(); hard_k=min(2048,int(neg_values.numel()))
    lneg=torch.topk(neg_values,hard_k).values.mean() if hard_k else obj.float().sum()*0
    lobj=0.75*lpos+0.25*lneg
    lbox=torch.stack(box_losses).mean() if box_losses else obj.float().sum()*0
    lcls=F.cross_entropy(torch.stack(class_logits),torch.tensor(class_targets,device=obj.device)) if class_logits else obj.float().sum()*0
    return lobj+lbox+lcls,{'obj':float(lobj.detach()),'box':float(lbox.detach()),'region':float(lcls.detach()),'positives':positives}

def ema(t,s,m):
    with torch.no_grad():
        for a,b in zip(t.parameters(),s.parameters()): a.mul_(m).add_(b,alpha=1-m)

def pick_vendor_balanced(rows,step,rng):
    vendors=sorted({r['device'] for r in rows}); vendor=vendors[step%len(vendors)]; pool=[r for r in rows if r['device']==vendor]; return rng.choice(pool)

def validate(model,cache,rows,shape,stats,max_boxes):
    model.eval(); values=[]; count=0
    with torch.no_grad():
        for row in rows:
            v,m=load_case(cache,row)
            for b in m['boxes']:
                a=np.asarray(b['aabb_xyz_voxel']); x,start=crop(v,(a[:3]+a[3:])/2,shape); x=norm(x,stats)
                with torch.autocast('cuda',dtype=torch.float16): out,_=model(torch.from_numpy(x[None,None]).float().cuda(),0.0); loss,_=targets_and_loss(out,m,start,shape)
                values.append(float(loss)); count+=1
                if count>=max_boxes: return float(np.mean(values)),count
    return float(np.mean(values)),count

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--project-root',type=Path,required=True); ap.add_argument('--config',type=Path,required=True); ap.add_argument('--output-dir',type=Path,required=True)
    args=ap.parse_args(); root=args.project_root.resolve(); out=args.output_dir.resolve(); out.mkdir(parents=True,exist_ok=True); cfg=yaml.safe_load(args.config.read_text())
    seed=int(cfg['seed']); random.seed(seed); np.random.seed(seed); torch.manual_seed(seed); torch.cuda.manual_seed_all(seed); rng=np.random.default_rng(seed)
    manifest=root/'manifests/inner_split_v1/nested_partitions_v1.csv'; roles=rows_for_fold(manifest,int(cfg['outer_fold']))
    with open(root/'manifests/split_v1/eligible_unlabeled_v1.csv',newline='',encoding='utf-8') as f: unlabeled=list(csv.DictReader(f))
    cache=root/'outputs/preprocessed_v1'; stats_path=out/'normalization_stats_v1.json'
    if stats_path.exists(): stats=json.loads(stats_path.read_text())
    else:
        stats=fit_stats(cache,roles['optimization'],unlabeled,cfg,rng); stats['optimization_case_ids']=[r['case_id'] for r in roles['optimization']]; stats['unlabeled_case_ids']=[r['case_id'] for r in unlabeled]; stats_path.write_text(json.dumps(stats,indent=2),encoding='utf-8')
    shape=list(map(int,cfg['patch_dhw'])); student=VRSSL3D().cuda(); teacher=copy.deepcopy(student).eval()
    for p in teacher.parameters(): p.requires_grad_(False)
    opt=torch.optim.AdamW(student.parameters(),lr=float(cfg['learning_rate']),weight_decay=float(cfg['weight_decay'])); scaler=torch.amp.GradScaler('cuda',init_scale=float(cfg['amp_initial_scale']),growth_interval=1000)
    start_epoch=0; best=float('inf'); ckpt_last=out/'checkpoint_last.pt'; history=[]
    if ckpt_last.exists():
        c=torch.load(ckpt_last,map_location='cpu',weights_only=False); student.load_state_dict(c['student']); teacher.load_state_dict(c['teacher']); opt.load_state_dict(c['optimizer']); scaler.load_state_dict(c['scaler']); start_epoch=c['epoch']+1; best=c['best']; history=c['history']; print(f'RESUME epoch={start_epoch}',flush=True)
    for epoch in range(start_epoch,int(cfg['epochs'])):
        student.train(); losses=[]; t0=time.time(); torch.cuda.reset_peak_memory_stats()
        for step in range(int(cfg['steps_per_epoch'])):
            lr=pick_vendor_balanced(roles['optimization'],step,rng); ur=pick_vendor_balanced(unlabeled,step+1,rng)
            x,start,m=positive_patch(cache,lr,shape,stats,rng); u,_,_=random_patch(cache,ur,shape,stats,rng)
            xt=torch.from_numpy(x[None,None]).float().cuda(); ut=torch.from_numpy(u[None,None]).float().cuda(); opt.zero_grad(set_to_none=True)
            with torch.autocast('cuda',dtype=torch.float16):
                pred,vlog=student(xt,float(cfg['grl_scale'])); lsup,parts=targets_and_loss(pred,m,start,shape); lv=F.cross_entropy(vlog.float(),torch.tensor([VENDOR[lr['device']]],device='cuda'))
            scaler.scale(lsup+float(cfg['vendor_loss_weight'])*lv).backward(); probs=[]
            with torch.no_grad():
                for s in (0.95,1.0,1.05):
                    with torch.autocast('cuda',dtype=torch.float16): tout,_=teacher(ut*s,0.0); probs.append(torch.sigmoid(tout[0][0]).float())
            stack=torch.stack(probs); target=stack.mean(0); var=stack.var(0); gate=(target>=float(cfg['pseudo_confidence']))&(var<=float(cfg['pseudo_variance_max']))
            with torch.autocast('cuda',dtype=torch.float16):
                upred,uvlog=student(ut,float(cfg['grl_scale'])); usp=torch.sigmoid(upred[0][0]).float(); lcons=F.mse_loss(usp[gate],target[gate]) if gate.any() else usp.sum()*0; luv=F.cross_entropy(uvlog.float(),torch.tensor([VENDOR[ur['device']]],device='cuda'))
            scaler.scale(float(cfg['consistency_loss_weight'])*lcons+float(cfg['vendor_loss_weight'])*luv).backward(); scaler.unscale_(opt)
            gn=torch.nn.utils.clip_grad_norm_(student.parameters(),float(cfg['gradient_clip']));
            if not torch.isfinite(gn): raise RuntimeError(f'Nonfinite gradient epoch={epoch} step={step}')
            scaler.step(opt); scaler.update(); ema(teacher,student,float(cfg['ema_momentum'])); losses.append(float(lsup.detach()))
        val,nval=validate(teacher,cache,roles['validation'],shape,stats,int(cfg['validation_max_boxes'])); rec={'epoch':epoch,'train_supervised_loss':float(np.mean(losses)),'validation_loss':val,'validation_boxes':nval,'seconds':time.time()-t0,'peak_reserved_gb':torch.cuda.max_memory_reserved()/1024**3}; history.append(rec); print(json.dumps(rec),flush=True)
        state={'epoch':epoch,'student':student.state_dict(),'teacher':teacher.state_dict(),'optimizer':opt.state_dict(),'scaler':scaler.state_dict(),'best':min(best,val),'history':history,'config':cfg,'manifest_sha256':digest(manifest),'normalization_sha256':digest(stats_path)}
        torch.save(state,ckpt_last)
        if val<best: best=val; torch.save(state,out/'checkpoint_best.pt')
        (out/'history_v1.json').write_text(json.dumps(history,indent=2),encoding='utf-8')
    report={'status':'PASS','outer_fold':cfg['outer_fold'],'seed':seed,'epochs_completed':len(history),'best_validation_loss':best,'optimization_cases':len(roles['optimization']),'validation_cases':len(roles['validation']),'unlabeled_cases':len(unlabeled),'outer_test_accessed':False,'checkpoint_best':str(out/'checkpoint_best.pt'),'history':history}
    rp=out/'fold0_pilot_report_v1.json'; rp.write_text(json.dumps(report,indent=2),encoding='utf-8'); files=[rp,out/'history_v1.json',stats_path,out/'checkpoint_best.pt']; (out/'PILOT_SHA256SUMS.txt').write_text(''.join(f'{digest(p)}  {p.name}\n' for p in files),encoding='utf-8'); print(json.dumps(report,indent=2)); print('FOLD-0 PILOT TRAINING: PASS')

if __name__=='__main__': main()
