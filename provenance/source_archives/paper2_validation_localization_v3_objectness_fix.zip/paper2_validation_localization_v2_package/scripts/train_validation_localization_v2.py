#!/usr/bin/env python3
from __future__ import annotations

import argparse, copy, csv, hashlib, importlib.util, json, random, sys, time
from pathlib import Path
import numpy as np
import torch
import torch.nn.functional as F
import yaml

from vrssl3d_train.model import VRSSL3D

VENDOR={'Kavo':0,'Meyer':1,'Newtom':2}

def load_module(name,path):
    spec=importlib.util.spec_from_file_location(name,path); mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod

def digest(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(4*1024*1024),b''): h.update(b)
    return h.hexdigest()

def crop_start(v,start,shape):
    start=np.asarray(start,int); shape=np.asarray(shape,int); end=start+shape
    lo=np.maximum(start,0); hi=np.minimum(end,np.asarray(v.shape)); dlo=lo-start; dhi=dlo+(hi-lo)
    out=np.full(tuple(shape),float(np.min(v)),np.float32)
    out[tuple(slice(a,b) for a,b in zip(dlo,dhi))]=np.asarray(v[tuple(slice(a,b) for a,b in zip(lo,hi))],np.float32)
    return out,start

def diverse_positive(base,cache,row,shape,stats,rng):
    v,m=base.load_case(cache,row); b=rng.choice(m['boxes']); a=np.asarray(b['aabb_xyz_voxel'],float); center_zyx=((a[:3]+a[3:])/2)[::-1]
    margin=np.minimum(np.asarray(shape)*0.15,24); desired=rng.uniform(margin,np.asarray(shape)-margin); start=np.rint(center_zyx-desired).astype(int)
    x,start=crop_start(v,start,shape); return base.norm(x,stats),start,m

def random_negative(base,cache,row,shape,stats,rng):
    v,m=base.load_case(cache,row); maxstart=np.maximum(np.asarray(v.shape)-np.asarray(shape),0); start=np.array([rng.integers(0,x+1) for x in maxstart]); x,start=crop_start(v,start,shape)
    empty={'boxes':[]}; return base.norm(x,stats),start,empty,m

def candidate_score(model,x):
    with torch.no_grad(),torch.autocast('cuda',dtype=torch.float16): out,_=model(torch.from_numpy(x[None,None]).float().cuda(),0.0)
    return float(torch.sigmoid(out[0][0]).max())

def hard_negative(base,model,cache,row,shape,stats,rng,n):
    candidates=[random_negative(base,cache,row,shape,stats,rng) for _ in range(n)]
    scores=[candidate_score(model,c[0]) for c in candidates]; return candidates[int(np.argmax(scores))]

def validation_froc(base,inf,model,cache,rows,shape,stride,stats,cfg):
    model.eval(); cases=[]
    with torch.no_grad():
        for row in rows:
            v,m=base.load_case(cache,row); cand=[]
            for z in inf.starts(v.shape[0],shape[0],stride[0]):
                for y in inf.starts(v.shape[1],shape[1],stride[1]):
                    for x in inf.starts(v.shape[2],shape[2],stride[2]):
                        p=base.norm(inf.crop_at(v,(z,y,x),shape),stats); t=torch.from_numpy(p[None,None]).float().cuda()
                        with torch.autocast('cuda',dtype=torch.float16): outputs,_=model(t,0.0)
                        cand.extend(inf.decode_patch(outputs,(z,y,x),shape,v.shape,int(cfg['per_patch_topk']),float(cfg['minimum_candidate_score'])))
            preds=inf.nms(cand,float(cfg['nms_iou']),int(cfg['maximum_detections_per_case'])); affine=np.asarray(m['target_affine_xyz_to_lps'])
            for p in preds:
                box=np.asarray(p['box_xyz']); p['center_lps']=inf.lps(affine,(box[:3]+box[3:])/2).tolist()
            gts=[]
            for b in m['boxes']:
                a=np.asarray(b['aabb_xyz_voxel']); gts.append({'box_xyz':a.tolist(),'center_lps':b['center_lps_mm'],'region_index':int(b['region_code'][1:])-1})
            cases.append({'predictions':preds,'ground_truth':gts})
    scores=sorted({0.0,1.0,*[round(p['score'],6) for c in cases for p in c['predictions']]}); total=sum(len(c['ground_truth']) for c in cases); curve=[]
    for th in scores:
        tp=fp=fn=0; errors=[]
        for c in cases:
            a,b,d,e=inf.match_case(c['predictions'],c['ground_truth'],th,float(cfg['matching_iou'])); tp+=a; fp+=b; fn+=d; errors+=e
        curve.append({'threshold':th,'sensitivity':tp/max(total,1),'fp_per_volume':fp/len(cases),'tp':tp,'fp':fp,'fn':fn,'median_center_error_mm':float(np.median(errors)) if errors else None})
    points=[]
    for budget in cfg['froc_budgets']:
        eligible=[x for x in curve if x['fp_per_volume']<=float(budget)]; best=max(eligible,key=lambda x:(x['sensitivity'],-x['fp_per_volume']))
        points.append({'budget':float(budget),**best})
    return {'partial_froc_score':float(np.mean([x['sensitivity'] for x in points])),'budget_points':points,'ground_truth_objects':total,'curve':curve}

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--project-root',type=Path,required=True); ap.add_argument('--config',type=Path,required=True); ap.add_argument('--output-dir',type=Path,required=True); args=ap.parse_args()
    root=args.project_root.resolve(); out=args.output_dir.resolve(); out.mkdir(parents=True,exist_ok=True); cfg=yaml.safe_load(args.config.read_text());
    base=load_module('pilot_base',root/'paper2_fold0_pilot_package/scripts/train_fold0_pilot.py'); inf=load_module('inference_base',root/'paper2_fold0_inference_package/scripts/infer_fold0_outer_test.py')
    seed=int(cfg['seed']); random.seed(seed); np.random.seed(seed); torch.manual_seed(seed); torch.cuda.manual_seed_all(seed); rng=np.random.default_rng(seed)
    manifest=root/'manifests/inner_split_v1/nested_partitions_v1.csv'; roles=base.rows_for_fold(manifest,int(cfg['outer_fold']))
    with open(root/'manifests/split_v1/eligible_unlabeled_v1.csv',newline='',encoding='utf-8') as f: unlabeled=list(csv.DictReader(f))
    cache=root/'outputs/preprocessed_v1'; stats_path=out/'normalization_stats_v2.json'
    if stats_path.exists(): stats=json.loads(stats_path.read_text())
    else:
        stats=base.fit_stats(cache,roles['optimization'],unlabeled,cfg,rng); stats['optimization_case_ids']=[r['case_id'] for r in roles['optimization']]; stats['unlabeled_case_ids']=[r['case_id'] for r in unlabeled]; stats_path.write_text(json.dumps(stats,indent=2),encoding='utf-8')
    shape=list(map(int,cfg['patch_dhw'])); stride=list(map(int,cfg['stride_dhw'])); student=VRSSL3D().cuda(); teacher=copy.deepcopy(student).eval()
    for p in teacher.parameters(): p.requires_grad_(False)
    opt=torch.optim.AdamW(student.parameters(),lr=float(cfg['learning_rate']),weight_decay=float(cfg['weight_decay'])); scaler=torch.amp.GradScaler('cuda',init_scale=float(cfg['amp_initial_scale']),growth_interval=1000)
    best=-1.0; history=[]; start_epoch=0; last=out/'checkpoint_last.pt'
    if last.exists():
        c=torch.load(last,map_location='cpu',weights_only=False); student.load_state_dict(c['student']); teacher.load_state_dict(c['teacher']); opt.load_state_dict(c['optimizer']); scaler.load_state_dict(c['scaler']); best=c['best']; history=c['history']; start_epoch=c['epoch']+1; print(f'RESUME epoch={start_epoch}',flush=True)
    for epoch in range(start_epoch,int(cfg['epochs'])):
        student.train(); epoch_losses=[]; pos_count=neg_count=accepted=0; t0=time.time(); torch.cuda.reset_peak_memory_stats()
        for step in range(int(cfg['steps_per_epoch'])):
            lr=base.pick_vendor_balanced(roles['optimization'],step,rng); ur=base.pick_vendor_balanced(unlabeled,step+1,rng); positive=rng.random()<float(cfg['positive_fraction'])
            if positive: x,xstart,xmeta=diverse_positive(base,cache,lr,shape,stats,rng); pos_count+=1
            else:
                if epoch>=int(cfg['hard_negative_start_epoch']): x,xstart,xmeta,_=hard_negative(base,teacher,cache,lr,shape,stats,rng,int(cfg['hard_negative_candidates']))
                else: x,xstart,xmeta,_=random_negative(base,cache,lr,shape,stats,rng)
                neg_count+=1
            u,_,_,_=random_negative(base,cache,ur,shape,stats,rng); xt=torch.from_numpy(x[None,None]).float().cuda(); ut=torch.from_numpy(u[None,None]).float().cuda(); opt.zero_grad(set_to_none=True)
            with torch.autocast('cuda',dtype=torch.float16): pred,vlog=student(xt,float(cfg['grl_scale'])); lsup,_=base.targets_and_loss(pred,xmeta,xstart,shape); lv=F.cross_entropy(vlog.float(),torch.tensor([VENDOR[lr['device']]],device='cuda'))
            scaler.scale(lsup+float(cfg['vendor_loss_weight'])*lv).backward(); probs=[]
            with torch.no_grad():
                for s in (0.95,1.0,1.05):
                    with torch.autocast('cuda',dtype=torch.float16): tout,_=teacher(ut*s,0.0); probs.append(torch.sigmoid(tout[0][0]).float())
            stack=torch.stack(probs); target=stack.mean(0); var=stack.var(0); gate=(target>=float(cfg['pseudo_confidence']))&(var<=float(cfg['pseudo_variance_max'])); accepted+=int(gate.sum())
            with torch.autocast('cuda',dtype=torch.float16): up,uv=student(ut,float(cfg['grl_scale'])); usp=torch.sigmoid(up[0][0]).float(); lc=F.mse_loss(usp[gate],target[gate]) if gate.any() else usp.sum()*0; luv=F.cross_entropy(uv.float(),torch.tensor([VENDOR[ur['device']]],device='cuda'))
            scaler.scale(float(cfg['consistency_loss_weight'])*lc+float(cfg['vendor_loss_weight'])*luv).backward(); scaler.unscale_(opt); gn=torch.nn.utils.clip_grad_norm_(student.parameters(),float(cfg['gradient_clip']))
            if not torch.isfinite(gn): raise RuntimeError(f'Nonfinite gradient epoch={epoch} step={step}')
            scaler.step(opt); scaler.update(); base.ema(teacher,student,float(cfg['ema_momentum'])); epoch_losses.append(float(lsup.detach()))
        do_val=((epoch+1)%int(cfg['validation_every_epochs'])==0 or epoch==int(cfg['epochs'])-1); vf=None
        if do_val: vf=validation_froc(base,inf,teacher,cache,roles['validation'],shape,stride,stats,cfg); score=vf['partial_froc_score']
        else: score=None
        rec={'epoch':epoch,'train_supervised_loss':float(np.mean(epoch_losses)),'positive_steps':pos_count,'negative_steps':neg_count,'accepted_pseudo_cells':accepted,'validation_partial_froc':score,'validation_budget_points':vf['budget_points'] if vf else None,'seconds':time.time()-t0,'peak_reserved_gb':torch.cuda.max_memory_reserved()/1024**3}; history.append(rec); print(json.dumps(rec),flush=True)
        state={'epoch':epoch,'student':student.state_dict(),'teacher':teacher.state_dict(),'optimizer':opt.state_dict(),'scaler':scaler.state_dict(),'best':best,'history':history,'config':cfg,'manifest_sha256':digest(manifest),'normalization_sha256':digest(stats_path)}
        if score is not None and score>best: best=score; state['best']=best; torch.save(state,out/'checkpoint_best.pt')
        state['best']=best; torch.save(state,last); (out/'history_v2.json').write_text(json.dumps(history,indent=2),encoding='utf-8')
    report={'status':'PASS','version':cfg['version'],'outer_fold':cfg['outer_fold'],'seed':seed,'epochs_completed':len(history),'best_validation_partial_froc':best,'optimization_cases':len(roles['optimization']),'validation_cases':len(roles['validation']),'unlabeled_cases':len(unlabeled),'calibration_accessed':False,'outer_test_accessed':False,'history':history}
    rp=out/'validation_localization_v2_report.json'; rp.write_text(json.dumps(report,indent=2),encoding='utf-8'); files=[rp,out/'history_v2.json',stats_path,out/'checkpoint_best.pt']; (out/'VALIDATION_V2_SHA256SUMS.txt').write_text(''.join(f'{digest(p)}  {p.name}\n' for p in files),encoding='utf-8'); print(json.dumps(report,indent=2)); print('VALIDATION-DRIVEN LOCALIZATION V2: PASS')

if __name__=='__main__': main()
