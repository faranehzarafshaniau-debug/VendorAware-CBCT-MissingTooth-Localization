Validation-driven Fold-0 localization v2

Corrects the failed centered-patch engineering pilot without consulting
outer-test predictions. Positive objects are placed throughout the patch,
random negatives and validation-driven hard negatives are included, and the
best EMA checkpoint is selected by full-volume sliding-window validation FROC
at 0.5, 1, 2, and 4 FP/volume. Calibration and outer-test caches are not read.

The run is resumable from checkpoint_last.pt. Its outer-test-access flag must
remain false. Final outer-test inference is not part of this package.
