import numpy as np
from vrssl3d_preprocess.preprocess import output_shape, resample


def test_output_shape_preserves_extent():
    assert output_shape((5, 7, 9), (0.5, 1.0, 2.0), (0.5, 0.5, 0.5)) == (17, 13, 9)


def test_identity_resampling():
    x = np.arange(4*5*6, dtype=np.float32).reshape(4,5,6)
    y = resample(x, (0.5,0.5,0.5), (0.5,0.5,0.5), 1)
    assert y.shape == x.shape and np.allclose(x, y)


def test_endpoint_mapping():
    x = np.zeros((5,7,9), dtype=np.float32); x[-1,-1,-1] = 1
    y = resample(x, (0.5,1.0,2.0), (0.5,0.5,0.5), 1)
    assert y.shape == (17,13,9) and np.isfinite(y).all()
