#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path
import sys
import time

import yaml

from vrssl3d_preprocess.preprocess import preprocess_case, save_case


ELIGIBLE = {"eligible_labeled", "eligible_unlabeled"}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(8 * 1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def valid_existing(case_dir: Path) -> bool:
    sums = case_dir / "SHA256SUMS.txt"
    if not sums.is_file():
        return False
    try:
        for line in sums.read_text(encoding="utf-8").splitlines():
            digest, name = line.split(None, 1)
            path = case_dir / name.strip()
            if not path.is_file() or sha256(path) != digest:
                return False
        meta = json.loads((case_dir / "metadata.json").read_text(encoding="utf-8"))
        return bool(meta.get("finite")) and not bool(meta.get("normalization_applied"))
    except Exception:
        return False


def load_rows(path: Path):
    with path.open(newline="", encoding="utf-8") as f:
        rows = [r for r in csv.DictReader(f) if r["primary_status"] in ELIGIBLE]
    if len(rows) != 156:
        raise RuntimeError(f"Expected 156 eligible cases, found {len(rows)}")
    if sum(r["primary_status"] == "eligible_labeled" for r in rows) != 83:
        raise RuntimeError("Expected 83 eligible labeled cases")
    if sum(r["primary_status"] == "eligible_unlabeled" for r in rows) != 73:
        raise RuntimeError("Expected 73 eligible unlabeled cases")
    if any(r["case_id"] in {"M38", "M61"} for r in rows):
        raise RuntimeError("Excluded duplicate M38/M61 entered eligible cache")
    return sorted(rows, key=lambda r: (r["cohort"], r["device"], r["case_id"]))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--project-root", type=Path, required=True)
    ap.add_argument("--eligibility", type=Path, required=True)
    ap.add_argument("--config", type=Path, required=True)
    ap.add_argument("--output-dir", type=Path, required=True)
    ap.add_argument("--continue-on-error", action="store_true")
    args = ap.parse_args()

    root = args.project_root.resolve()
    out = args.output_dir.resolve(); out.mkdir(parents=True, exist_ok=True)
    cfg = yaml.safe_load(args.config.read_text(encoding="utf-8"))
    spacing = tuple(map(float, cfg["target_spacing_xyz_mm"]))
    rows = load_rows(args.eligibility)
    results, failures = [], []
    started = time.time()

    for index, row in enumerate(rows, 1):
        case_dir = out / row["device"] / row["case_id"]
        prefix = f"[{index:03d}/{len(rows):03d}] {row['cohort']}/{row['device']}/{row['case_id']}"
        try:
            if valid_existing(case_dir):
                meta = json.loads((case_dir / "metadata.json").read_text(encoding="utf-8"))
                state = "SKIP_VALID"
            else:
                print(f"{prefix} PROCESS", flush=True)
                volume, meta = preprocess_case(root / "data_raw", row["cohort"], row["device"], row["case_id"], spacing, cfg["interpolation_order"])
                if abs(float(volume.min())) > 65504 or abs(float(volume.max())) > 65504:
                    raise ValueError("Resampled intensity exceeds float16 finite range")
                save_case(volume, meta, out)
                state = "CREATED"
            result = {
                "cohort": row["cohort"], "device": row["device"], "case_id": row["case_id"],
                "primary_status": row["primary_status"], "state": state,
                "source_shape_zyx": meta["source_shape_zyx"], "target_shape_zyx": meta["target_shape_zyx"],
                "boxes": len(meta["boxes"]), "finite": meta["finite"]
            }
            results.append(result)
            print(f"{prefix} {state} shape={meta['target_shape_zyx']} boxes={len(meta['boxes'])}", flush=True)
        except Exception as exc:
            failure = {"cohort": row["cohort"], "device": row["device"], "case_id": row["case_id"], "error": repr(exc)}
            failures.append(failure)
            print(f"{prefix} FAILED {exc!r}", file=sys.stderr, flush=True)
            if not args.continue_on_error:
                raise

        checkpoint = {"status": "RUNNING", "completed": len(results), "failed": len(failures),
                      "total": len(rows), "last_case": row["case_id"], "failures": failures}
        (out / "cache_progress_v1.json").write_text(json.dumps(checkpoint, indent=2), encoding="utf-8")

    labeled = sum(r["primary_status"] == "eligible_labeled" for r in results)
    unlabeled = sum(r["primary_status"] == "eligible_unlabeled" for r in results)
    rois = sum(int(r["boxes"]) for r in results)
    status = "PASS" if not failures and len(results) == 156 and labeled == 83 and unlabeled == 73 and rois == 111 else "FAIL"
    report = {"status": status, "total_cases": len(results), "labeled_cases": labeled,
              "unlabeled_cases": unlabeled, "roi_objects": rois, "failed_cases": len(failures),
              "target_spacing_xyz_mm": spacing, "normalization_applied": False,
              "elapsed_seconds": time.time() - started, "failures": failures, "cases": results}
    report_path = out / "full_cache_report_v1.json"
    report_path.write_text(json.dumps(report, indent=2), encoding="utf-8")
    fields = ["cohort","device","case_id","primary_status","state","source_shape_zyx","target_shape_zyx","boxes","finite"]
    with (out / "full_cache_manifest_v1.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields); w.writeheader()
        for r in results:
            x = dict(r); x["source_shape_zyx"] = "x".join(map(str, x["source_shape_zyx"])); x["target_shape_zyx"] = "x".join(map(str, x["target_shape_zyx"])); w.writerow(x)
    top_files = [report_path, out / "full_cache_manifest_v1.csv"]
    (out / "FULL_CACHE_SHA256SUMS.txt").write_text("".join(f"{sha256(p)}  {p.name}\n" for p in top_files), encoding="utf-8")
    print(json.dumps({k: report[k] for k in ("status","total_cases","labeled_cases","unlabeled_cases","roi_objects","failed_cases","elapsed_seconds")}, indent=2))
    print(f"FULL PREPROCESS CACHE: {status}")
    if status != "PASS":
        raise SystemExit(2)


if __name__ == "__main__":
    main()
