#!/usr/bin/env python3
from __future__ import annotations

import argparse, hashlib, json
from pathlib import Path
import yaml

from vrssl3d_preprocess.preprocess import preprocess_case, save_case


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--project-root', type=Path, required=True)
    ap.add_argument('--config', type=Path, required=True)
    ap.add_argument('--output-dir', type=Path, required=True)
    args = ap.parse_args()
    root = args.project_root.resolve(); cfg = yaml.safe_load(args.config.read_text())
    spacing = tuple(map(float, cfg['target_spacing_xyz_mm']))
    report = {'status': 'PASS', 'config_version': cfg['version'], 'target_spacing_xyz_mm': spacing,
              'normalization_policy': cfg['normalization_policy'], 'cases': []}
    for item in cfg['cases']:
        print(f"Processing {item['device']}/{item['case_id']} ...", flush=True)
        vol, meta = preprocess_case(root/'data_raw', item['cohort'], item['device'], item['case_id'], spacing, cfg['interpolation_order'])
        case_dir = save_case(vol, meta, args.output_dir)
        report['cases'].append({'case_id': item['case_id'], 'device': item['device'],
                                'source_shape_zyx': meta['source_shape_zyx'], 'target_shape_zyx': meta['target_shape_zyx'],
                                'boxes': len(meta['boxes']), 'all_boxes_inside': all(b['inside_resampled_volume'] for b in meta['boxes']),
                                'finite': meta['finite'], 'cache_dir': str(case_dir)})
        print(report['cases'][-1], flush=True)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    out = args.output_dir/'preprocess_smoke_report_v1.json'
    out.write_text(json.dumps(report, indent=2), encoding='utf-8')
    digest = hashlib.sha256(out.read_bytes()).hexdigest()
    (args.output_dir/'PREPROCESS_SMOKE_SHA256.txt').write_text(f"{digest}  {out.name}\n", encoding='utf-8')
    print(json.dumps(report, indent=2)); print('PREPROCESS SMOKE: PASS')


if __name__ == '__main__': main()
