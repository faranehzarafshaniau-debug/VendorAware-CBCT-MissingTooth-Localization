PAPER2 preprocessing smoke package v1

Purpose:
- physical DICOM ordering and strict geometry validation
- RescaleSlope/Intercept application
- 0.5-mm isotropic trilinear resampling
- LPS/mm ROI transformation and in-volume validation
- float16 cache without clipping or normalization

Normalization is intentionally deferred. For each outer fold, robust clipping
statistics must be fitted only on that fold's optimization partition.
Raw DICOM and JSON files are never modified.

Run tests first, then the three-case smoke command supplied in ChatGPT.

The full-cache runner reads only cases whose locked primary_status is
eligible_labeled or eligible_unlabeled. It verifies the expected 83/73 case
counts, excludes M38/M61, supports safe resume by SHA256-valid case caches,
and requires 111 retained ROI objects for final PASS.
