from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import json
import numpy as np
import pydicom


@dataclass(frozen=True)
class Geometry:
    files: tuple[Path, ...]
    positions: np.ndarray
    projections: np.ndarray
    row_direction: np.ndarray
    column_direction: np.ndarray
    slice_direction: np.ndarray
    spacing_xyz: tuple[float, float, float]
    rows: int
    columns: int
    affine_xyz_to_lps: np.ndarray

    @property
    def shape_zyx(self):
        return (len(self.files), self.rows, self.columns)

    def lps_to_xyz(self, points):
        pts = np.atleast_2d(np.asarray(points, dtype=np.float64))
        hom = np.c_[pts, np.ones(len(pts))]
        out = (np.linalg.inv(self.affine_xyz_to_lps) @ hom.T).T[:, :3]
        return out[0] if np.asarray(points).ndim == 1 else out

    def xyz_to_lps(self, points):
        pts = np.atleast_2d(np.asarray(points, dtype=np.float64))
        hom = np.c_[pts, np.ones(len(pts))]
        out = (self.affine_xyz_to_lps @ hom.T).T[:, :3]
        return out[0] if np.asarray(points).ndim == 1 else out


def _vec(ds, tag, n):
    if not hasattr(ds, tag):
        raise ValueError(f"Missing {tag}: {getattr(ds, 'filename', '?')}")
    v = np.asarray(getattr(ds, tag), dtype=np.float64)
    if v.shape != (n,):
        raise ValueError(f"Invalid {tag} shape: {v.shape}")
    return v


def load_geometry(case_dir: Path, atol=1e-5):
    paths = sorted(p for p in Path(case_dir).rglob('*') if p.is_file() and p.suffix.lower() in {'.dcm', '.dicom'})
    if not paths:
        raise ValueError(f"No DICOM files: {case_dir}")
    rec = []
    for p in paths:
        ds = pydicom.dcmread(p, stop_before_pixels=True, force=False)
        rec.append((p, ds, _vec(ds, 'ImageOrientationPatient', 6), _vec(ds, 'ImagePositionPatient', 3), _vec(ds, 'PixelSpacing', 2)))
    ref_o = rec[0][2]
    row = ref_o[:3] / np.linalg.norm(ref_o[:3])
    col = ref_o[3:] / np.linalg.norm(ref_o[3:])
    normal = np.cross(row, col); normal /= np.linalg.norm(normal)
    if abs(row @ col) > atol:
        raise ValueError('Non-orthogonal DICOM orientation')
    rows, cols = int(rec[0][1].Rows), int(rec[0][1].Columns)
    ps = rec[0][4]
    seen = set()
    for p, ds, orient, _, spacing in rec:
        if not np.allclose(orient, ref_o, atol=atol): raise ValueError(f"Orientation changes: {p}")
        if (int(ds.Rows), int(ds.Columns)) != (rows, cols): raise ValueError(f"Matrix changes: {p}")
        if not np.allclose(spacing, ps, atol=atol): raise ValueError(f"Pixel spacing changes: {p}")
        uid = str(ds.SOPInstanceUID)
        if uid in seen: raise ValueError(f"Duplicate SOPInstanceUID: {uid}")
        seen.add(uid)
    pos = np.asarray([r[3] for r in rec]); proj = pos @ normal
    order = np.argsort(proj, kind='stable'); proj = proj[order]
    diffs = np.diff(proj)
    if len(diffs) and np.any(diffs <= atol): raise ValueError('Duplicate slice position')
    dz = float(np.median(diffs)) if len(diffs) else float(getattr(rec[0][1], 'SliceThickness', 1.0))
    if len(diffs) and not np.allclose(diffs, dz, rtol=2e-3, atol=2e-4):
        raise ValueError(f"Irregular slice spacing: {diffs.min()}..{diffs.max()}")
    row_sp, col_sp = map(float, ps)
    affine = np.eye(4, dtype=np.float64)
    affine[:3, 0] = row * col_sp
    affine[:3, 1] = col * row_sp
    affine[:3, 2] = normal * dz
    affine[:3, 3] = pos[order][0]
    return Geometry(tuple(rec[i][0] for i in order), pos[order], proj, row, col, normal,
                    (col_sp, row_sp, dz), rows, cols, affine)


def load_volume(geom: Geometry):
    out = np.empty(geom.shape_zyx, dtype=np.float32)
    for z, path in enumerate(geom.files):
        ds = pydicom.dcmread(path, force=False)
        arr = ds.pixel_array.astype(np.float32)
        out[z] = arr * float(getattr(ds, 'RescaleSlope', 1.0)) + float(getattr(ds, 'RescaleIntercept', 0.0))
    if not np.isfinite(out).all(): raise ValueError('Non-finite rescaled pixels')
    return out


def load_boxes(mask_dir: Path):
    boxes = []
    if not Path(mask_dir).is_dir(): return boxes
    for path in sorted(Path(mask_dir).glob('*.json')):
        payload = json.loads(path.read_text(encoding='utf-8'))
        for m in payload.get('markups', []):
            if m.get('type') != 'ROI' or m.get('roiType') != 'Box': raise ValueError(f"Unsupported markup: {path}")
            if m.get('coordinateSystem') != 'LPS' or m.get('coordinateUnits') != 'mm': raise ValueError(f"Expected LPS/mm: {path}")
            center = np.asarray(m['center'], dtype=np.float64); size = np.asarray(m['size'], dtype=np.float64)
            orient = np.asarray(m['orientation'], dtype=np.float64).reshape(3, 3)
            if center.shape != (3,) or size.shape != (3,) or np.any(size <= 0): raise ValueError(f"Invalid box: {path}")
            signs = np.array([[a,b,c] for a in (-1,1) for b in (-1,1) for c in (-1,1)], dtype=np.float64)
            corners = center + (signs * (size / 2.0)) @ orient.T
            region = path.name.split('_R', 1)[1][:2] if '_R' in path.name else 'UNKNOWN'
            boxes.append({'center_lps': center, 'size_mm': size, 'orientation': orient,
                          'corners_lps': corners, 'region_code': f'R{region}', 'source': path.name})
    return boxes
