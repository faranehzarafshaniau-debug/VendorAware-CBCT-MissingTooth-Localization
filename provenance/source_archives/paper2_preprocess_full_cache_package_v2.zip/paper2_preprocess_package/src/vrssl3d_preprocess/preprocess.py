from __future__ import annotations

import hashlib
import json
from pathlib import Path
import numpy as np
from scipy.ndimage import affine_transform

def output_shape(old_shape_zyx, old_spacing_xyz, target_spacing_xyz):
    old_xyz = np.asarray(old_shape_zyx[::-1], dtype=np.int64)
    old_sp = np.asarray(old_spacing_xyz, dtype=np.float64)
    new_sp = np.asarray(target_spacing_xyz, dtype=np.float64)
    new_xyz = np.rint((old_xyz - 1) * old_sp / new_sp).astype(np.int64) + 1
    return tuple(int(v) for v in new_xyz[::-1])


def resample(volume, old_spacing_xyz, target_spacing_xyz, order=1):
    old_sp_zyx = np.asarray(old_spacing_xyz[::-1], dtype=np.float64)
    new_sp_zyx = np.asarray(target_spacing_xyz[::-1], dtype=np.float64)
    shape = output_shape(volume.shape, old_spacing_xyz, target_spacing_xyz)
    matrix = np.diag(new_sp_zyx / old_sp_zyx)
    return affine_transform(volume, matrix=matrix, offset=0.0, output_shape=shape,
                            order=int(order), mode='nearest', prefilter=False, output=np.float32)


def preprocess_case(data_root: Path, cohort: str, device: str, case_id: str,
                    target_spacing_xyz=(0.5,0.5,0.5), order=1):
    from .geometry import load_geometry, load_volume, load_boxes
    image_dir = Path(data_root) / cohort / 'image' / device / case_id
    geom = load_geometry(image_dir)
    vol = load_volume(geom)
    res = resample(vol, geom.spacing_xyz, target_spacing_xyz, order)
    target_affine = geom.affine_xyz_to_lps.copy()
    target_affine[:3, 0] = geom.row_direction * target_spacing_xyz[0]
    target_affine[:3, 1] = geom.column_direction * target_spacing_xyz[1]
    target_affine[:3, 2] = geom.slice_direction * target_spacing_xyz[2]
    inv = np.linalg.inv(target_affine)
    boxes = load_boxes(Path(data_root) / cohort / 'mask' / device / case_id) if cohort == 'annotated' else []
    serial_boxes = []
    upper = np.asarray(res.shape[::-1], dtype=np.float64) - 1
    for b in boxes:
        hom = np.c_[b['corners_lps'], np.ones(8)]
        corners_xyz = (inv @ hom.T).T[:, :3]
        lo, hi = corners_xyz.min(0), corners_xyz.max(0)
        inside = bool(np.all(lo >= -1.0) and np.all(hi <= upper + 1.0))
        serial_boxes.append({'region_code': b['region_code'], 'source': b['source'],
                             'center_lps_mm': b['center_lps'].tolist(), 'size_mm': b['size_mm'].tolist(),
                             'aabb_xyz_voxel': [*lo.tolist(), *hi.tolist()], 'inside_resampled_volume': inside})
        if not inside: raise ValueError(f"Box outside resampled volume: {case_id}/{b['source']}")
    meta = {'case_id': case_id, 'cohort': cohort, 'device': device,
            'source_shape_zyx': list(geom.shape_zyx), 'source_spacing_xyz_mm': list(geom.spacing_xyz),
            'target_shape_zyx': list(res.shape), 'target_spacing_xyz_mm': list(target_spacing_xyz),
            'source_affine_xyz_to_lps': geom.affine_xyz_to_lps.tolist(),
            'target_affine_xyz_to_lps': target_affine.tolist(), 'slice_order_physical': True,
            'normalization_applied': False, 'rescale_metadata_applied': True,
            'pixel_min': float(res.min()), 'pixel_max': float(res.max()),
            'finite': bool(np.isfinite(res).all()), 'boxes': serial_boxes}
    return res, meta


def save_case(volume, meta, output_dir: Path):
    case_dir = Path(output_dir) / meta['device'] / meta['case_id']; case_dir.mkdir(parents=True, exist_ok=True)
    vol_path = case_dir / 'volume_resampled_float16.npy'
    meta_path = case_dir / 'metadata.json'
    np.save(vol_path, volume.astype(np.float16), allow_pickle=False)
    meta_path.write_text(json.dumps(meta, indent=2), encoding='utf-8')
    hashes = []
    for p in (vol_path, meta_path): hashes.append(f"{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.name}")
    (case_dir / 'SHA256SUMS.txt').write_text('\n'.join(hashes)+'\n', encoding='utf-8')
    return case_dir
