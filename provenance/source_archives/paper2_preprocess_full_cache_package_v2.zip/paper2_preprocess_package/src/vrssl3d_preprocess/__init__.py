"""Leakage-safe physical preprocessing for VR-SSL3D."""
