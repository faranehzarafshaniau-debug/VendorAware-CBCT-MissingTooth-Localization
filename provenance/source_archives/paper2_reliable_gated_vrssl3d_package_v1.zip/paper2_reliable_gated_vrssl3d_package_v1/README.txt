FULL RELIABILITY-GATED VR-SSL3D PACKAGE v1

Purpose
-------
Run the primary proposed method from the independently trained Pure Supervised-3D checkpoints.
The package reuses the locked cache and nested manifests. It does not rebuild or inspect raw DICOM.

Reliability gate
----------------
- objectness confidence
- predictive objectness variance
- class confidence and class agreement
- box-regression variance
- weak-view geometric stability using stride-aligned 3-D translations
- maximum accepted pseudo cells per patch

Safety
------
- validation is used for model selection
- calibration and outer-test roles are never loaded by the training/evaluation path
- labeled-only normalization statistics are copied from the matched Pure Supervised-3D fold
- each run is resumable through checkpoint_last.pt

Recommended execution
---------------------
1. Run Fold 0 only with scripts/run_fold0_pilot_v1.sh.
2. Inspect finite losses, accepted pseudo cells, validation pFROC, and checksums.
3. Only after Fold 0 passes, run scripts/run_full_5fold_v1.sh.

This is the primary method package, not the complete A1-A6 ablation package.
