#!/usr/bin/env bash
set -euo pipefail
cd /mnt/morph-cbct-data/PAPER2_LOCALIZATION_CANONICAL
source .venv/bin/activate
export PYTHONPATH="$PWD/paper2_real_model_smoke_package/src"
mkdir -p outputs/fold0_full_reliable_gated_vrssl3d_v1 logs
cp outputs/fold0_pure_supervised_v1/normalization_stats_pure_supervised_v1.json outputs/fold0_full_reliable_gated_vrssl3d_v1/normalization_stats_v2.json
python paper2_reliable_gated_vrssl3d_package_v1/scripts/train_reliable_gated_vrssl3d.py \
  --project-root "$PWD" \
  --config paper2_reliable_gated_vrssl3d_package_v1/configs/fold0_full_reliable_gated_vrssl3d_v1.yaml \
  --initial-checkpoint outputs/fold0_pure_supervised_v1/checkpoint_best.pt \
  --output-dir outputs/fold0_full_reliable_gated_vrssl3d_v1
