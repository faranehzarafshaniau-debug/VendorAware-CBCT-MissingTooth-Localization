#!/usr/bin/env bash
set -euo pipefail
cd /mnt/morph-cbct-data/PAPER2_LOCALIZATION_CANONICAL
source .venv/bin/activate
export PYTHONPATH="$PWD/paper2_real_model_smoke_package/src"
for fold in 0 1 2 3 4; do
  out="outputs/fold${fold}_full_reliable_gated_vrssl3d_v1"
  mkdir -p "$out" logs
  if test ! -f "$out/normalization_stats_v2.json"; then
    cp "outputs/fold${fold}_pure_supervised_v1/normalization_stats_pure_supervised_v1.json" "$out/normalization_stats_v2.json"
  fi
  echo "===== FULL GATED FOLD ${fold} START $(date -Is) ====="
  python paper2_reliable_gated_vrssl3d_package_v1/scripts/train_reliable_gated_vrssl3d.py \
    --project-root "$PWD" \
    --config "paper2_reliable_gated_vrssl3d_package_v1/configs/fold${fold}_full_reliable_gated_vrssl3d_v1.yaml" \
    --initial-checkpoint "outputs/fold${fold}_pure_supervised_v1/checkpoint_best.pt" \
    --output-dir "$out"
  echo "===== FULL GATED FOLD ${fold} PASS $(date -Is) ====="
done
echo "===== ALL FULL RELIABILITY-GATED FOLDS PASS $(date -Is) ====="
