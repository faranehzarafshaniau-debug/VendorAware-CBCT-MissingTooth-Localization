#!/usr/bin/env python3
from pathlib import Path
import yaml

root=Path(__file__).resolve().parents[2]
out=Path(__file__).resolve().parents[1]/'configs'
out.mkdir(parents=True,exist_ok=True)

base={
 'epochs':15,'steps_per_epoch':96,'patch_dhw':[128,160,160],'stride_dhw':[96,120,120],
 'positive_fraction':0.80,'hard_negative_candidates':2,'hard_negative_start_epoch':0,
 'validation_every_epochs':5,'learning_rate':2.0e-5,'weight_decay':1.0e-4,
 'ema_momentum':0.99,'amp_initial_scale':128.0,'gradient_clip':12.0,
 'grl_scale':0.10,'vendor_loss_weight':0.10,'consistency_loss_weight':0.25,
 'ssl_ramp_start_epoch':0,'ssl_ramp_epochs':5,
 'pseudo_confidence':0.70,'pseudo_variance_max':0.01,
 'pseudo_class_confidence':0.55,'pseudo_box_variance_max':0.02,
 'pseudo_max_cells_per_patch':64,'normalization_voxels_per_case':20000,
 'normalization_percentiles':[0.5,99.5],'per_patch_topk':30,
 'minimum_candidate_score':0.001,'nms_iou':0.10,
 'maximum_detections_per_case':100,'matching_iou':0.10,
 'froc_budgets':[0.5,1.0,2.0,4.0],
 'teacher_views':[
   {'intensity_scale':1.00,'shift_zyx':[0,0,0]},
   {'intensity_scale':0.95,'shift_zyx':[0,0,0]},
   {'intensity_scale':1.05,'shift_zyx':[0,0,0]},
   {'intensity_scale':1.00,'shift_zyx':[4,0,0]},
   {'intensity_scale':1.00,'shift_zyx':[-4,0,0]},
   {'intensity_scale':1.00,'shift_zyx':[0,4,0]},
   {'intensity_scale':1.00,'shift_zyx':[0,0,4]},
 ]
}
for fold in range(5):
    cfg=dict(base); cfg.update(version=f'fold{fold}_full_reliable_gated_vrssl3d_v1',outer_fold=fold,seed=53026+fold)
    p=out/f'fold{fold}_full_reliable_gated_vrssl3d_v1.yaml'
    p.write_text(yaml.safe_dump(cfg,sort_keys=False))
    print(p)
print('FULL GATED CONFIG PREPARATION: PASS')
