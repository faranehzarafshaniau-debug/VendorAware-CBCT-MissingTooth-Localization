from .model import Conventional3DDetector

__all__ = ["Conventional3DDetector"]
