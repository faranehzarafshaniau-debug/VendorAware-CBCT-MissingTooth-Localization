from __future__ import annotations

import torch
from torch import nn


class ResidualBlock(nn.Module):
    def __init__(self, cin: int, cout: int, stride: int = 1):
        super().__init__()
        self.conv1 = nn.Conv3d(cin, cout, 3, stride=stride, padding=1, bias=False)
        self.norm1 = nn.GroupNorm(min(8, cout), cout)
        self.conv2 = nn.Conv3d(cout, cout, 3, padding=1, bias=False)
        self.norm2 = nn.GroupNorm(min(8, cout), cout)
        self.skip = (
            nn.Identity()
            if cin == cout and stride == 1
            else nn.Conv3d(cin, cout, 1, stride=stride, bias=False)
        )
        self.act = nn.SiLU(inplace=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        identity = self.skip(x)
        x = self.act(self.norm1(self.conv1(x)))
        return self.act(self.norm2(self.conv2(x)) + identity)


class Conventional3DDetector(nn.Module):
    """Architecture-matched single-output 3-D encoder-decoder detector.

    This control intentionally excludes FPN, a vendor discriminator and an SSL
    mechanism.  Its output tuple matches the locked localization evaluator.
    """

    def __init__(self, base: int = 24, width: int = 48, regions: int = 4):
        super().__init__()
        self.stem = nn.Sequential(
            nn.Conv3d(1, base, 3, stride=2, padding=1, bias=False),
            nn.GroupNorm(min(8, base), base),
            nn.SiLU(inplace=False),
        )
        self.enc1 = nn.Sequential(ResidualBlock(base, base), ResidualBlock(base, base))
        self.enc2 = nn.Sequential(ResidualBlock(base, base * 2, 2), ResidualBlock(base * 2, base * 2))
        self.enc3 = nn.Sequential(ResidualBlock(base * 2, base * 4, 2), ResidualBlock(base * 4, base * 4))
        self.enc4 = nn.Sequential(ResidualBlock(base * 4, base * 8, 2), ResidualBlock(base * 8, base * 8))
        self.up4 = nn.Conv3d(base * 8, width, 1)
        self.skip3 = nn.Conv3d(base * 4, width, 1)
        self.skip2 = nn.Conv3d(base * 2, width, 1)
        self.skip1 = nn.Conv3d(base, width, 1)
        self.refine = nn.Sequential(
            nn.Conv3d(width, width, 3, padding=1, bias=False),
            nn.GroupNorm(min(8, width), width),
            nn.SiLU(inplace=False),
            nn.Conv3d(width, width, 3, padding=1, bias=False),
            nn.GroupNorm(min(8, width), width),
            nn.SiLU(inplace=False),
        )
        self.objectness = nn.Conv3d(width, 1, 3, padding=1)
        self.box = nn.Conv3d(width, 6, 3, padding=1)
        self.region = nn.Conv3d(width, regions, 3, padding=1)

    @staticmethod
    def _up(x: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        return torch.nn.functional.interpolate(
            x, size=target.shape[-3:], mode="trilinear", align_corners=False
        )

    def forward(self, x: torch.Tensor, grl_scale: float = 0.0):
        del grl_scale
        e1 = self.enc1(self.stem(x))
        e2 = self.enc2(e1)
        e3 = self.enc3(e2)
        e4 = self.enc4(e3)
        z = self._up(self.up4(e4), e3) + self.skip3(e3)
        z = self._up(z, e2) + self.skip2(e2)
        z = self._up(z, e1) + self.skip1(e1)
        z = self.refine(z)
        outputs = [(self.objectness(z), self.box(z), self.region(z))]
        unused_vendor = torch.zeros((x.shape[0], 3), device=x.device, dtype=z.dtype)
        return outputs, unused_vendor
