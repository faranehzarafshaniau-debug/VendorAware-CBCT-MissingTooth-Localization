#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
import copy
import yaml


ROOT = Path(__file__).resolve().parents[2]
PACKAGE = Path(__file__).resolve().parents[1]
SEEDS = [141026, 241026, 341026, 441026, 541026]


def pure_source(fold: int) -> Path:
    return PACKAGE / "templates" / "pure" / f"fold{fold}_pure_supervised_v1.yaml"


def gated_source(fold: int) -> Path:
    return PACKAGE / "templates" / "gated" / f"fold{fold}_full_reliable_gated_vrssl3d_v1.yaml"


def main() -> None:
    out = PACKAGE / "configs"
    out.mkdir(parents=True, exist_ok=True)
    count = 0
    for repeat, base_seed in enumerate(SEEDS, 1):
        for fold in range(5):
            conventional = yaml.safe_load(pure_source(fold).read_text())
            conventional["version"] = f"step2_conventional_fold{fold}_repeat{repeat}_v1"
            conventional["outer_fold"] = fold
            conventional["seed"] = base_seed + fold
            conventional["benchmark_status"] = "post_lock_exploratory"
            p = out / f"conventional_fold{fold}_repeat{repeat}_v1.yaml"
            p.write_text(yaml.safe_dump(conventional, sort_keys=False))

            mean_teacher = copy.deepcopy(yaml.safe_load(gated_source(fold).read_text()))
            mean_teacher["version"] = f"step2_mean_teacher_fold{fold}_repeat{repeat}_v1"
            mean_teacher["outer_fold"] = fold
            mean_teacher["seed"] = base_seed + fold
            mean_teacher["vendor_loss_weight"] = 0.0
            mean_teacher["grl_scale"] = 0.0
            mean_teacher["pseudo_confidence"] = 0.70
            mean_teacher["pseudo_variance_max"] = 1.0e12
            mean_teacher["pseudo_class_confidence"] = 0.0
            mean_teacher["pseudo_box_variance_max"] = 1.0e12
            mean_teacher["teacher_views"] = [
                {"intensity_scale": 1.0, "shift_zyx": [0, 0, 0]}
            ]
            mean_teacher["benchmark_status"] = "post_lock_exploratory"
            mean_teacher["mechanism"] = "ema_confidence_only"
            p = out / f"mean_teacher_fold{fold}_repeat{repeat}_v1.yaml"
            p.write_text(yaml.safe_dump(mean_teacher, sort_keys=False))
            count += 2
    print(f"STEP2 CONFIGS: PASS ({count} files)")


if __name__ == "__main__":
    main()
