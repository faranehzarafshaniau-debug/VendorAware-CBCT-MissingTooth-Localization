#!/usr/bin/env bash
set -euo pipefail

cd /mnt/morph-cbct-data/PAPER2_LOCALIZATION_CANONICAL
source .venv/bin/activate

PACKAGE="paper2_step2_benchmarks_package_v1"
export PYTHONPATH="$PWD/$PACKAGE/src:$PWD/paper2_real_model_smoke_package/src"

python "$PACKAGE/scripts/prepare_configs.py"

for repeat in 1 2 3 4 5
do
    for fold in 0 1 2 3 4
    do
        echo "===== STEP2 CONVENTIONAL REPEAT ${repeat} FOLD ${fold} START $(date -Is) ====="
        python "$PACKAGE/scripts/train_conventional_3d.py" \
          --project-root "$PWD" \
          --config "$PACKAGE/configs/conventional_fold${fold}_repeat${repeat}_v1.yaml" \
          --output-dir "outputs/step2_conventional_fold${fold}_repeat${repeat}_v1"
        echo "===== STEP2 CONVENTIONAL REPEAT ${repeat} FOLD ${fold} PASS $(date -Is) ====="

        echo "===== STEP2 MEAN TEACHER REPEAT ${repeat} FOLD ${fold} START $(date -Is) ====="
        python "$PACKAGE/scripts/train_mean_teacher_3d.py" \
          --project-root "$PWD" \
          --config "$PACKAGE/configs/mean_teacher_fold${fold}_repeat${repeat}_v1.yaml" \
          --output-dir "outputs/step2_mean_teacher_fold${fold}_repeat${repeat}_v1" \
          --initial-checkpoint "outputs/fold${fold}_pure_supervised_v1/checkpoint_best.pt"
        echo "===== STEP2 MEAN TEACHER REPEAT ${repeat} FOLD ${fold} PASS $(date -Is) ====="
    done
done

python "$PACKAGE/scripts/audit_and_summarize.py" --project-root "$PWD"
echo "===== STEP2 ALL 50 RUNS PASS $(date -Is) ====="
