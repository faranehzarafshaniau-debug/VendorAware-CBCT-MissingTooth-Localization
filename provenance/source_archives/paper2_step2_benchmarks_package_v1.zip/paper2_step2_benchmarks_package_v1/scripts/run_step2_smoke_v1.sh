#!/usr/bin/env bash
set -euo pipefail

cd /mnt/morph-cbct-data/PAPER2_LOCALIZATION_CANONICAL
source .venv/bin/activate
PACKAGE="paper2_step2_benchmarks_package_v1"
export PYTHONPATH="$PWD/$PACKAGE/src:$PWD/paper2_real_model_smoke_package/src"
python "$PACKAGE/scripts/prepare_configs.py"

python - <<'PY'
from pathlib import Path
import yaml
for method in ("conventional", "mean_teacher"):
    src=Path(f"paper2_step2_benchmarks_package_v1/configs/{method}_fold0_repeat1_v1.yaml")
    cfg=yaml.safe_load(src.read_text())
    cfg["version"] += "_smoke"
    cfg["epochs"]=1
    cfg["steps_per_epoch"]=2
    cfg["validation_every_epochs"]=1
    dst=src.with_name(src.stem+"_smoke.yaml")
    dst.write_text(yaml.safe_dump(cfg,sort_keys=False))
PY

rm -rf outputs/step2_conventional_smoke_v1 outputs/step2_mean_teacher_smoke_v1
python "$PACKAGE/scripts/train_conventional_3d.py" \
  --project-root "$PWD" \
  --config "$PACKAGE/configs/conventional_fold0_repeat1_v1_smoke.yaml" \
  --output-dir outputs/step2_conventional_smoke_v1
python "$PACKAGE/scripts/train_mean_teacher_3d.py" \
  --project-root "$PWD" \
  --config "$PACKAGE/configs/mean_teacher_fold0_repeat1_v1_smoke.yaml" \
  --output-dir outputs/step2_mean_teacher_smoke_v1 \
  --initial-checkpoint outputs/fold0_pure_supervised_v1/checkpoint_best.pt
echo "STEP2 TWO-METHOD SMOKE: PASS"
