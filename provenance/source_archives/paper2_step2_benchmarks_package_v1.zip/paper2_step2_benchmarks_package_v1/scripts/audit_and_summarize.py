#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import statistics
from pathlib import Path


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(4 * 1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def verify_manifest(directory: Path, name: str) -> None:
    for line in (directory / name).read_text().splitlines():
        expected, filename = line.split(maxsplit=1)
        filename = filename.strip().lstrip("*")
        actual = digest(directory / filename)
        if actual != expected:
            raise RuntimeError(f"Checksum mismatch: {directory / filename}")


def best_from_history(history):
    evaluated = [r for r in history if r.get("validation_partial_froc") is not None]
    if not evaluated:
        raise RuntimeError("No validation result")
    return max(evaluated, key=lambda r: (r["validation_partial_froc"], -r["epoch"]))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--project-root", type=Path, required=True)
    args = ap.parse_args()
    root = args.project_root.resolve()
    rows = []
    for repeat in range(1, 6):
        for fold in range(5):
            specs = [
                ("conventional_3d", root / f"outputs/step2_conventional_fold{fold}_repeat{repeat}_v1", "conventional_3d_report_v1.json", "CONVENTIONAL_3D_SHA256SUMS.txt"),
                ("mean_teacher_3d", root / f"outputs/step2_mean_teacher_fold{fold}_repeat{repeat}_v1", "mean_teacher_3d_report_v1.json", "MEAN_TEACHER_3D_SHA256SUMS.txt"),
            ]
            for method, directory, report_name, checksum_name in specs:
                verify_manifest(directory, checksum_name)
                report = json.loads((directory / report_name).read_text())
                if report["status"] != "PASS":
                    raise RuntimeError(f"Non-PASS report: {directory}")
                if report.get("calibration_accessed") or report.get("outer_test_accessed"):
                    raise RuntimeError(f"Partition firewall failure: {directory}")
                best = best_from_history(report["history"])
                points = {float(x["budget"]): x for x in best["validation_budget_points"]}
                rows.append({
                    "method": method,
                    "repeat": repeat,
                    "fold": fold,
                    "seed": report["seed"],
                    "best_epoch": best["epoch"],
                    "validation_pfroc": best["validation_partial_froc"],
                    "sensitivity_0_5": points[0.5]["sensitivity"],
                    "sensitivity_1": points[1.0]["sensitivity"],
                    "sensitivity_2": points[2.0]["sensitivity"],
                    "sensitivity_4": points[4.0]["sensitivity"],
                    "center_error_1_mm": points[1.0]["median_center_error_mm"],
                    "seconds_total": sum(float(x["seconds"]) for x in report["history"]),
                    "peak_reserved_gb": max(float(x["peak_reserved_gb"]) for x in report["history"]),
                })
    if len(rows) != 50:
        raise RuntimeError(f"Expected 50 formal runs, found {len(rows)}")
    summary = {"status": "PASS", "post_lock_exploratory": True, "formal_runs": len(rows), "methods": {}}
    for method in ("conventional_3d", "mean_teacher_3d"):
        subset = [r for r in rows if r["method"] == method]
        values = [float(r["validation_pfroc"]) for r in subset]
        summary["methods"][method] = {
            "n": len(values), "mean_pfroc": statistics.mean(values),
            "sd_pfroc": statistics.stdev(values), "min_pfroc": min(values),
            "max_pfroc": max(values), "mean_training_seconds": statistics.mean(float(r["seconds_total"]) for r in subset),
            "max_peak_reserved_gb": max(float(r["peak_reserved_gb"]) for r in subset),
        }
    out = root / "outputs/step2_benchmark_summary_v1"
    out.mkdir(parents=True, exist_ok=True)
    csv_path = out / "step2_benchmark_runs_v1.csv"
    with csv_path.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)
    json_path = out / "step2_benchmark_summary_v1.json"
    json_path.write_text(json.dumps(summary, indent=2))
    (out / "STEP2_BENCHMARK_SHA256SUMS.txt").write_text(
        f"{digest(csv_path)}  {csv_path.name}\n{digest(json_path)}  {json_path.name}\n"
    )
    print(json.dumps(summary, indent=2))
    print("STEP2 BENCHMARK AUDIT: PASS")


if __name__ == "__main__":
    main()
