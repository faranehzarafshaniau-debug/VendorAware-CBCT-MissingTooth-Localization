#!/usr/bin/env python3
from __future__ import annotations

import argparse
import copy
import importlib.util
import json
import random
import time
from pathlib import Path

import numpy as np
import torch
import yaml

from benchmark3d.model import Conventional3DDetector


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", type=Path, required=True)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()

    root = args.project_root.resolve()
    output = args.output_dir.resolve()
    output.mkdir(parents=True, exist_ok=True)
    cfg = yaml.safe_load(args.config.read_text(encoding="utf-8"))

    trainer = load_module(
        "validation_trainer",
        root / "paper2_validation_localization_v2_package/scripts/train_validation_localization_v2.py",
    )
    base = load_module(
        "pilot_base",
        root / "paper2_fold0_pilot_package/scripts/train_fold0_pilot.py",
    )
    inference = load_module(
        "inference_base",
        root / "paper2_fold0_inference_package/scripts/infer_fold0_outer_test.py",
    )

    seed = int(cfg["seed"])
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    rng = np.random.default_rng(seed)

    manifest = root / "manifests/inner_split_v1/nested_partitions_v1.csv"
    roles = base.rows_for_fold(manifest, int(cfg["outer_fold"]))
    optimization = roles["optimization"]
    validation = roles["validation"]
    cache = root / "outputs/preprocessed_v1"

    # Leakage guard: normalization is fitted on labeled optimization cases only.
    stats_path = output / "normalization_stats_conventional_3d_v1.json"
    if stats_path.exists():
        stats = json.loads(stats_path.read_text(encoding="utf-8"))
    else:
        stats = base.fit_stats(cache, optimization, [], cfg, rng)
        stats["normalization_scope"] = "labeled_optimization_only"
        stats["optimization_case_ids"] = [r["case_id"] for r in optimization]
        stats["unlabeled_case_ids"] = []
        stats_path.write_text(json.dumps(stats, indent=2), encoding="utf-8")

    if int(stats["fit_cases"]) != len(optimization):
        raise RuntimeError("Normalization leakage guard failed: fit_cases != optimization cases")
    if stats.get("unlabeled_case_ids"):
        raise RuntimeError("Normalization leakage guard failed: unlabeled cases present")

    shape = list(map(int, cfg["patch_dhw"]))
    stride = list(map(int, cfg["stride_dhw"]))
    student = Conventional3DDetector().cuda()
    ema_model = copy.deepcopy(student).eval()
    for parameter in ema_model.parameters():
        parameter.requires_grad_(False)

    optimizer = torch.optim.AdamW(
        student.parameters(),
        lr=float(cfg["learning_rate"]),
        weight_decay=float(cfg["weight_decay"]),
    )
    scaler = torch.amp.GradScaler(
        "cuda", init_scale=float(cfg["amp_initial_scale"]), growth_interval=1000
    )

    best = -1.0
    history = []
    start_epoch = 0
    last_path = output / "checkpoint_last.pt"
    if last_path.exists():
        checkpoint = torch.load(last_path, map_location="cpu", weights_only=False)
        student.load_state_dict(checkpoint["student"])
        ema_model.load_state_dict(checkpoint["teacher"])
        optimizer.load_state_dict(checkpoint["optimizer"])
        scaler.load_state_dict(checkpoint["scaler"])
        best = float(checkpoint["best"])
        history = checkpoint["history"]
        start_epoch = int(checkpoint["epoch"]) + 1
        for group in optimizer.param_groups:
            group["lr"] = float(cfg["learning_rate"])
            group["weight_decay"] = float(cfg["weight_decay"])
        if not (output / "checkpoint_best.pt").exists():
            torch.save(checkpoint, output / "checkpoint_best.pt")
        print(f"RESUME epoch={start_epoch}", flush=True)

    for epoch in range(start_epoch, int(cfg["epochs"])):
        student.train()
        epoch_losses = []
        positive_steps = 0
        negative_steps = 0
        started = time.time()
        torch.cuda.reset_peak_memory_stats()

        for _step in range(int(cfg["steps_per_epoch"])):
            # Uniform labeled-case sampling. Vendor labels are not used by the baseline.
            row = optimization[int(rng.integers(0, len(optimization)))]
            positive = rng.random() < float(cfg["positive_fraction"])
            if positive:
                patch, start, metadata = trainer.diverse_positive(
                    base, cache, row, shape, stats, rng
                )
                positive_steps += 1
            else:
                if epoch >= int(cfg["hard_negative_start_epoch"]):
                    patch, start, metadata, _ = trainer.hard_negative(
                        base,
                        ema_model,
                        cache,
                        row,
                        shape,
                        stats,
                        rng,
                        int(cfg["hard_negative_candidates"]),
                    )
                else:
                    patch, start, metadata, _ = trainer.random_negative(
                        base, cache, row, shape, stats, rng
                    )
                negative_steps += 1

            tensor = torch.from_numpy(patch[None, None]).float().cuda()
            optimizer.zero_grad(set_to_none=True)
            with torch.autocast("cuda", dtype=torch.float16):
                outputs, _unused_vendor_logits = student(tensor, 0.0)
                supervised_loss, loss_parts = base.targets_and_loss(
                    outputs, metadata, start, shape
                )

            scaler.scale(supervised_loss).backward()
            scaler.unscale_(optimizer)
            gradient_norm = torch.nn.utils.clip_grad_norm_(
                student.parameters(), float(cfg["gradient_clip"])
            )
            if not torch.isfinite(gradient_norm):
                raise RuntimeError(f"Nonfinite gradient epoch={epoch}")
            scaler.step(optimizer)
            scaler.update()
            base.ema(ema_model, student, float(cfg["ema_momentum"]))
            epoch_losses.append(float(supervised_loss.detach()))

        do_validation = (
            (epoch + 1) % int(cfg["validation_every_epochs"]) == 0
            or epoch == int(cfg["epochs"]) - 1
        )
        validation_result = None
        score = None
        if do_validation:
            validation_result = trainer.validation_froc(
                base,
                inference,
                ema_model,
                cache,
                validation,
                shape,
                stride,
                stats,
                cfg,
            )
            score = float(validation_result["partial_froc_score"])

        record = {
            "epoch": epoch,
            "train_supervised_loss": float(np.mean(epoch_losses)),
            "positive_steps": positive_steps,
            "negative_steps": negative_steps,
            "accepted_pseudo_cells": 0,
            "consistency_weight": 0.0,
            "vendor_loss_weight": 0.0,
            "grl_scale": 0.0,
            "unlabeled_batches": 0,
            "validation_partial_froc": score,
            "validation_budget_points": (
                validation_result["budget_points"] if validation_result else None
            ),
            "seconds": time.time() - started,
            "peak_reserved_gb": torch.cuda.max_memory_reserved() / 1024**3,
        }
        history.append(record)
        print(json.dumps(record), flush=True)

        state = {
            "epoch": epoch,
            "student": student.state_dict(),
            "teacher": ema_model.state_dict(),
            "optimizer": optimizer.state_dict(),
            "scaler": scaler.state_dict(),
            "best": best,
            "history": history,
            "config": cfg,
            "training_regime": "conventional_single_scale_3d_supervised",
            "architecture": "Conventional3DDetector",
            "manifest_sha256": trainer.digest(manifest),
            "normalization_sha256": trainer.digest(stats_path),
        }
        if score is not None and score > best:
            best = score
            state["best"] = best
            torch.save(state, output / "checkpoint_best.pt")
        state["best"] = best
        torch.save(state, last_path)
        (output / "history_conventional_3d_v1.json").write_text(
            json.dumps(history, indent=2), encoding="utf-8"
        )

    report = {
        "status": "PASS",
        "version": cfg["version"],
        "training_regime": "conventional_single_scale_3d_supervised",
        "architecture": "Conventional3DDetector",
        "outer_fold": int(cfg["outer_fold"]),
        "seed": seed,
        "epochs_completed": len(history),
        "best_validation_partial_froc": best,
        "optimization_cases": len(optimization),
        "validation_cases": len(validation),
        "normalization_fit_cases": int(stats["fit_cases"]),
        "normalization_scope": stats["normalization_scope"],
        "unlabeled_cases_loaded": 0,
        "unlabeled_batches": 0,
        "vendor_loss_weight_effective": 0.0,
        "grl_scale_effective": 0.0,
        "consistency_loss_weight_effective": 0.0,
        "calibration_accessed": False,
        "outer_test_accessed": False,
        "history": history,
    }
    report_path = output / "conventional_3d_report_v1.json"
    history_path = output / "history_conventional_3d_v1.json"
    report_path.write_text(json.dumps(report, indent=2), encoding="utf-8")
    files = [report_path, history_path, stats_path, output / "checkpoint_best.pt"]
    (output / "CONVENTIONAL_3D_SHA256SUMS.txt").write_text(
        "".join(f"{trainer.digest(path)}  {path.name}\n" for path in files),
        encoding="utf-8",
    )
    print(json.dumps(report, indent=2))
    print("CONVENTIONAL 3D DETECTOR: PASS")


if __name__ == "__main__":
    main()
