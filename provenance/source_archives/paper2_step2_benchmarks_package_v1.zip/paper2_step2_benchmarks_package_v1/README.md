# Paper 2 - Step 2 benchmark package v1

This package implements the reviewer-requested post-lock benchmark extensions:

1. `Conventional3DDetector`: an architecture-matched single-output 3-D encoder-decoder detector trained on labeled optimization cases only.
2. `Mean-Teacher-3D`: the existing teacher-student trainer configured as confidence-only EMA consistency, with uncertainty, geometric-stability and vendor-adversarial mechanisms disabled.

Both methods use the immutable case roles, physical-space preprocessing, patch budget, validation evaluator, and five fixed repeats. The formal plan contains 50 runs (2 methods x 5 folds x 5 repeats). Calibration and outer-test partitions are not accessed.

## Install on the canonical server

From `/mnt/morph-cbct-data/PAPER2_LOCALIZATION_CANONICAL`:

```bash
unzip -o paper2_step2_benchmarks_package_v1.zip
cd paper2_step2_benchmarks_package_v1
sha256sum -c PACKAGE_SHA256SUMS.txt
cd ..
python -m py_compile \
  paper2_step2_benchmarks_package_v1/src/benchmark3d/model.py \
  paper2_step2_benchmarks_package_v1/scripts/*.py
bash -n paper2_step2_benchmarks_package_v1/scripts/*.sh
```

## Mandatory smoke test

```bash
bash paper2_step2_benchmarks_package_v1/scripts/run_step2_smoke_v1.sh \
  |& tee logs/step2_benchmarks_smoke_v1.log
```

Proceed only after `STEP2 TWO-METHOD SMOKE: PASS` and checksum verification of both smoke outputs.

## Formal execution

```bash
nohup bash paper2_step2_benchmarks_package_v1/scripts/run_step2_benchmarks_5x5_v1.sh \
  > logs/step2_benchmarks_5x5_v1.log 2>&1 &
echo $! | tee logs/step2_benchmarks_5x5_v1.pid
```

The runner is resumable because each trainer uses `checkpoint_last.pt`.

## Progress check

```bash
ps -p "$(cat logs/step2_benchmarks_5x5_v1.pid)" -o pid,stat,etime,%cpu,%mem,cmd \
  || echo "STEP2 BATCH FINISHED"
grep -E 'STEP2 (CONVENTIONAL|MEAN TEACHER)|STEP2 ALL 50 RUNS|Traceback|RuntimeError' \
  logs/step2_benchmarks_5x5_v1.log | tail -20
grep '"epoch"' logs/step2_benchmarks_5x5_v1.log | tail -8
nvidia-smi
```

## Locked interpretation

These are post-lock exploratory extensions because the original outer-test results were already known when Step 2 was specified. They cannot redefine the original primary comparison. Negative and neutral results must be retained.
