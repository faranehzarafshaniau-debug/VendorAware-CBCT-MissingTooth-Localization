#!/usr/bin/env python3
from __future__ import annotations

import argparse, copy, hashlib, json, time
from pathlib import Path
import numpy as np
import torch
import torch.nn.functional as F

from vrssl3d_train.model import VRSSL3D


VENDOR = {'Kavo': 0, 'Meyer': 1, 'Newtom': 2}


def load_case(cache, device, case_id):
    d = cache/device/case_id
    v = np.load(d/'volume_resampled_float16.npy', mmap_mode='r')
    m = json.loads((d/'metadata.json').read_text(encoding='utf-8'))
    return v, m


def crop(volume, center_xyz, shape_dhw):
    shape = np.asarray(shape_dhw); center_zyx = np.asarray(center_xyz[::-1], dtype=float)
    start = np.rint(center_zyx - shape/2).astype(int); end = start + shape
    src_lo = np.maximum(start, 0); src_hi = np.minimum(end, np.asarray(volume.shape))
    dst_lo = src_lo-start; dst_hi = dst_lo+(src_hi-src_lo)
    out = np.full(tuple(shape), float(np.min(volume)), dtype=np.float32)
    out[tuple(slice(a,b) for a,b in zip(dst_lo,dst_hi))] = np.asarray(volume[tuple(slice(a,b) for a,b in zip(src_lo,src_hi))], dtype=np.float32)
    return out, start


def normalize_smoke(x):
    lo, hi = np.percentile(x, [0.5, 99.5])
    x = np.clip(x, lo, hi); mean, std = float(x.mean()), float(x.std())
    x = ((x-mean)/max(std, 1e-6)).astype(np.float32, copy=False)
    return x, {'p005': float(lo), 'p995': float(hi), 'mean': mean, 'std': std}


def supervised_loss(outputs, meta, start_zyx, patch_dhw):
    box = meta['boxes'][0]; aabb = np.asarray(box['aabb_xyz_voxel'], dtype=float)
    center_xyz = (aabb[:3]+aabb[3:])/2; extent_xyz = aabb[3:]-aabb[:3]
    local_zyx = center_xyz[::-1]-start_zyx
    obj, reg, cls = outputs[0]; grid = np.asarray(obj.shape[-3:])
    index = np.clip(np.floor(local_zyx/np.asarray(patch_dhw)*grid).astype(int), 0, grid-1)
    target_obj = torch.zeros_like(obj); target_obj[0,0,index[0],index[1],index[2]] = 1
    l_obj = F.binary_cross_entropy_with_logits(obj, target_obj, pos_weight=torch.tensor(100.0, device=obj.device))
    pred_box = reg[0,:,index[0],index[1],index[2]].float()
    patch_xyz = np.asarray(patch_dhw[::-1], dtype=float)
    target_box = torch.tensor(np.r_[center_xyz-(start_zyx[::-1]), extent_xyz]/np.r_[patch_xyz,patch_xyz], device=obj.device, dtype=torch.float32)
    l_box = F.smooth_l1_loss(pred_box, target_box)
    region = int(box['region_code'][1:])-1
    l_region = F.cross_entropy(cls[0,:,index[0],index[1],index[2]].float().unsqueeze(0), torch.tensor([region], device=obj.device))
    return l_obj+l_box+l_region, {'objectness': float(l_obj.detach()), 'box': float(l_box.detach()), 'region': float(l_region.detach()), 'positive_p2_zyx': index.tolist()}


def ema_update(teacher, student, momentum=0.99):
    with torch.no_grad():
        for t,s in zip(teacher.parameters(), student.parameters()): t.mul_(momentum).add_(s, alpha=1-momentum)


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--project-root',type=Path,required=True); ap.add_argument('--output-dir',type=Path,required=True)
    ap.add_argument('--patch-dhw',type=int,nargs=3,default=[128,160,160]); args=ap.parse_args()
    if not torch.cuda.is_available(): raise RuntimeError('CUDA unavailable')
    root=args.project_root.resolve(); cache=root/'outputs/preprocessed_v1'; out=args.output_dir; out.mkdir(parents=True,exist_ok=True)
    torch.manual_seed(20260815); np.random.seed(20260815); torch.cuda.manual_seed_all(20260815)
    lv,lm=load_case(cache,'Kavo','K01'); uv,um=load_case(cache,'Meyer','M73')
    a=np.asarray(lm['boxes'][0]['aabb_xyz_voxel']); center=(a[:3]+a[3:])/2
    lx,lstart=crop(lv,center,args.patch_dhw); ux,ustart=crop(uv,(np.asarray(uv.shape[::-1])-1)/2,args.patch_dhw)
    lx,ln=normalize_smoke(lx); ux,un=normalize_smoke(ux)
    student=VRSSL3D().cuda(); teacher=copy.deepcopy(student).eval()
    for p in teacher.parameters(): p.requires_grad_(False)
    opt=torch.optim.AdamW(student.parameters(),lr=1e-4,weight_decay=1e-4)
    scaler=torch.amp.GradScaler('cuda', init_scale=128.0, growth_factor=2.0,
                                backoff_factor=0.5, growth_interval=1000)
    student.train(); torch.cuda.reset_peak_memory_stats(); start=time.perf_counter(); opt.zero_grad(set_to_none=True)
    x_l=torch.from_numpy(lx[None,None]).float().cuda(non_blocking=True)
    x_u=torch.from_numpy(ux[None,None]).float().cuda(non_blocking=True)
    if x_l.dtype != torch.float32 or x_u.dtype != torch.float32:
        raise RuntimeError(f'Input dtype lock failed: {x_l.dtype}/{x_u.dtype}')
    with torch.autocast('cuda',dtype=torch.float16):
        lout,lvendor=student(x_l,grl_scale=0.1); lsup,parts=supervised_loss(lout,lm,lstart,args.patch_dhw)
        lven_l=F.cross_entropy(lvendor.float(),torch.tensor([VENDOR['Kavo']],device='cuda')); loss_l=lsup+0.1*lven_l
    scaler.scale(loss_l).backward()
    teacher_probs=[]
    with torch.no_grad():
        for scale in (0.95,1.0,1.05):
            with torch.autocast('cuda',dtype=torch.float16):
                tout,_=teacher(x_u*scale); teacher_probs.append(torch.sigmoid(tout[0][0]).float())
    target=torch.stack(teacher_probs).mean(0)
    with torch.autocast('cuda',dtype=torch.float16):
        uout,uvendor=student(x_u,grl_scale=0.1)
        lcons=F.mse_loss(torch.sigmoid(uout[0][0]).float(),target)
        lven_u=F.cross_entropy(uvendor.float(),torch.tensor([VENDOR['Meyer']],device='cuda')); loss_u=lcons+0.1*lven_u
    scaler.scale(loss_u).backward(); scaler.unscale_(opt)
    grads_finite=all(torch.isfinite(p.grad).all().item() for p in student.parameters() if p.grad is not None)
    grad_norm=float(torch.nn.utils.clip_grad_norm_(student.parameters(),12.0)) if grads_finite else float('inf')
    optimizer_step_applied=False; ema_updated=False; checkpoint_written=False
    ckpt=out/'real_model_smoke_checkpoint.pt'
    if grads_finite and np.isfinite(grad_norm):
        scaler.step(opt); scaler.update(); optimizer_step_applied=True
        ema_update(teacher,student); ema_updated=True
        torch.save({'student':student.state_dict(),'teacher':teacher.state_dict(),'optimizer':opt.state_dict(),
                    'scaler':scaler.state_dict(),'patch_dhw':args.patch_dhw,'seed':20260815},ckpt)
        checkpoint_written=True
    else:
        scaler.update()
    torch.cuda.synchronize(); elapsed=time.perf_counter()-start
    report={'status':'PASS','data_source':'real_preprocessed_cache','labeled_case':'K01','unlabeled_case':'M73','real_roi_used':True,
            'patch_dhw':args.patch_dhw,'normalization':'smoke_only_per_patch_not_for_final_training','labeled_stats':ln,'unlabeled_stats':un,
            'loss_supervised':float(lsup.detach()),'loss_consistency':float(lcons.detach()),'loss_vendor_labeled':float(lven_l.detach()),
            'loss_vendor_unlabeled':float(lven_u.detach()),'loss_parts':parts,'gradient_norm':grad_norm,'losses_finite':bool(all(np.isfinite(v) for v in [float(lsup),float(lcons),float(lven_l),float(lven_u),grad_norm])),
            'gradients_finite':grads_finite,'amp_initial_scale':128.0,'optimizer_step_applied':optimizer_step_applied,
            'teacher_passes_sequential':3,'ema_updated':ema_updated,'checkpoint_written':checkpoint_written,'peak_allocated_gb':torch.cuda.max_memory_allocated()/1024**3,
            'peak_reserved_gb':torch.cuda.max_memory_reserved()/1024**3,'elapsed_seconds':elapsed,'gpu':torch.cuda.get_device_name(0),'torch':torch.__version__}
    if not report['losses_finite'] or not grads_finite or not optimizer_step_applied or not ema_updated or not checkpoint_written: report['status']='FAIL'
    rp=out/'real_model_training_smoke_v1.json'; rp.write_text(json.dumps(report,indent=2),encoding='utf-8')
    sums=f"{hashlib.sha256(rp.read_bytes()).hexdigest()}  {rp.name}\n"
    if checkpoint_written: sums+=f"{hashlib.sha256(ckpt.read_bytes()).hexdigest()}  {ckpt.name}\n"
    (out/'REAL_MODEL_SMOKE_SHA256.txt').write_text(sums,encoding='utf-8')
    print(json.dumps(report,indent=2)); print('REAL-DATA VR-SSL3D TRAINING SMOKE: '+report['status'])
    if report['status']!='PASS': raise SystemExit(2)


if __name__=='__main__': main()
