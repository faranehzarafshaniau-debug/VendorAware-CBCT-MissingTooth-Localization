VR-SSL3D real-data training smoke v1

This is not a synthetic profiler. It loads K01 and M73 from the locked 0.5-mm
cache, centers a labeled patch on a released ROI, builds supervised dense
localization targets, runs the student and three sequential no-gradient EMA
teacher views, applies consistency and gradient-reversal vendor losses,
backpropagates with FP16 AMP, clips gradients, updates the optimizer and EMA,
and writes a restorable checkpoint plus a checksum-locked report.

Per-patch normalization is smoke-only. Final pilot/full training will use
fold-fitted statistics and will not reuse smoke normalization values.
