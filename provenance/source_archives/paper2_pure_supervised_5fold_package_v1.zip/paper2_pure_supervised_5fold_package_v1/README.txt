PAPER 2 — PURE SUPERVISED-3D FIVE-FOLD PACKAGE v1

Purpose
-------
Create a scientifically clean labeled-only localization baseline.

Guards
------
- Normalization is fitted only on each fold's labeled optimization cases.
- No unlabeled manifest is opened by the trainer.
- No unlabeled batch, teacher pseudo-label, or consistency loss is computed.
- Vendor logits are ignored; GRL scale and vendor-loss weight are effectively zero.
- Vendor identity is not used for sampling; labeled optimization cases are sampled uniformly.
- Calibration and outer-test roles are never passed to training or validation.
- EMA weight averaging is retained as an optimization/inference stabilizer and uses labeled updates only.

Outputs
-------
outputs/fold{0..4}_pure_supervised_v1/
  checkpoint_best.pt
  checkpoint_last.pt
  history_pure_supervised_v1.json
  normalization_stats_pure_supervised_v1.json
  pure_supervised_report_v1.json
  PURE_SUPERVISED_SHA256SUMS.txt

The runner is restart-safe: an interrupted fold resumes from checkpoint_last.pt.
