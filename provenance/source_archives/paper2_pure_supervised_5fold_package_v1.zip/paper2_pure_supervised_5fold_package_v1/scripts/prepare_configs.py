#!/usr/bin/env python3
from pathlib import Path
import yaml

root = Path(__file__).resolve().parents[2]
source_dir = root / "paper2_validation_localization_v2_package/configs"
output_dir = Path(__file__).resolve().parents[1] / "configs"
output_dir.mkdir(parents=True, exist_ok=True)

sources = {
    0: source_dir / "fold0_validation_v3.yaml",
    1: source_dir / "fold1_supervised_v3.yaml",
    2: source_dir / "fold2_supervised_v3.yaml",
    3: source_dir / "fold3_supervised_v3.yaml",
    4: source_dir / "fold4_supervised_v3.yaml",
}

for fold, source in sources.items():
    cfg = yaml.safe_load(source.read_text(encoding="utf-8"))
    cfg["version"] = f"fold{fold}_pure_supervised_3d_v1"
    cfg["outer_fold"] = fold
    cfg["grl_scale"] = 0.0
    cfg["vendor_loss_weight"] = 0.0
    cfg["consistency_loss_weight"] = 0.0
    target = output_dir / f"fold{fold}_pure_supervised_v1.yaml"
    target.write_text(yaml.safe_dump(cfg, sort_keys=False), encoding="utf-8")
    print(f"fold={fold} source={source.name} seed={cfg['seed']} output={target}")

print("PURE SUPERVISED CONFIG PREPARATION: PASS")
