#!/usr/bin/env python3
import json
from pathlib import Path

root = Path(__file__).resolve().parents[2]
for fold in range(5):
    directory = root / f"outputs/fold{fold}_pure_supervised_v1"
    report = json.loads((directory / "pure_supervised_report_v1.json").read_text())
    assert report["status"] == "PASS"
    assert report["training_regime"] == "pure_supervised_labeled_only"
    assert report["normalization_fit_cases"] == report["optimization_cases"]
    assert report["normalization_scope"] == "labeled_optimization_only"
    assert report["unlabeled_cases_loaded"] == 0
    assert report["unlabeled_batches"] == 0
    assert report["vendor_loss_weight_effective"] == 0.0
    assert report["grl_scale_effective"] == 0.0
    assert report["consistency_loss_weight_effective"] == 0.0
    assert report["calibration_accessed"] is False
    assert report["outer_test_accessed"] is False
    print(
        f"fold={fold} optimization={report['optimization_cases']} "
        f"validation={report['validation_cases']} "
        f"best_pfroc={report['best_validation_partial_froc']:.6f} PASS"
    )
print("PURE SUPERVISED OUTPUT AUDIT: PASS")
