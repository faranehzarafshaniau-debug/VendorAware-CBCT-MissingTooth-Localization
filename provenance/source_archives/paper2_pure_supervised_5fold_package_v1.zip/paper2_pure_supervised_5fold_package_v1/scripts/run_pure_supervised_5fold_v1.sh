#!/usr/bin/env bash
set -euo pipefail

cd /mnt/morph-cbct-data/PAPER2_LOCALIZATION_CANONICAL
source .venv/bin/activate
export PYTHONPATH="$PWD/paper2_real_model_smoke_package/src"

python paper2_pure_supervised_5fold_package_v1/scripts/prepare_configs.py

for fold in 0 1 2 3 4
do
    echo "===== PURE SUPERVISED FOLD ${fold} START $(date -Is) ====="
    python paper2_pure_supervised_5fold_package_v1/scripts/train_pure_supervised_3d.py \
        --project-root "$PWD" \
        --config "paper2_pure_supervised_5fold_package_v1/configs/fold${fold}_pure_supervised_v1.yaml" \
        --output-dir "outputs/fold${fold}_pure_supervised_v1"
    echo "===== PURE SUPERVISED FOLD ${fold} PASS $(date -Is) ====="
done

echo "===== ALL PURE SUPERVISED FOLDS PASS $(date -Is) ====="
