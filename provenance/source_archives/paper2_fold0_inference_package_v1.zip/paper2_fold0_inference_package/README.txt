Fold-0 sliding-window inference v1

Runs the locked best EMA-teacher checkpoint on all 17 Fold-0 outer-test
volumes using overlapping 128x160x160 patches. It decodes P2 detections,
performs class-wise 3D NMS, saves case-level predictions, and recomputes a
full exploratory FROC curve with 3D-IoU matching.

The <=1 FP/volume point is explicitly exploratory because it is observed on
outer-test. The final paper threshold must be selected on calibration data.
