#!/usr/bin/env python3
from __future__ import annotations

import argparse, csv, hashlib, json, math, time
from pathlib import Path
import numpy as np
import torch
import torch.nn.functional as F
import yaml

from vrssl3d_train.model import VRSSL3D

def digest(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(4*1024*1024),b''): h.update(b)
    return h.hexdigest()

def starts(n,p,s):
    if n<=p: return [0]
    a=list(range(0,n-p+1,s))
    if a[-1]!=n-p: a.append(n-p)
    return a

def crop_at(v,start,shape):
    start=np.asarray(start); shape=np.asarray(shape); end=start+shape
    lo=np.maximum(start,0); hi=np.minimum(end,np.asarray(v.shape)); dlo=lo-start; dhi=dlo+(hi-lo)
    out=np.full(tuple(shape),float(np.min(v)),np.float32)
    out[tuple(slice(a,b) for a,b in zip(dlo,dhi))]=np.asarray(v[tuple(slice(a,b) for a,b in zip(lo,hi))],np.float32)
    return out

def norm(x,s): return ((np.clip(x,s['p_low'],s['p_high'])-s['mean'])/max(s['std'],1e-6)).astype(np.float32)

def iou3(a,b):
    lo=np.maximum(a[:3],b[:3]); hi=np.minimum(a[3:],b[3:]); inter=np.prod(np.maximum(hi-lo,0.0))
    va=np.prod(np.maximum(a[3:]-a[:3],0.0)); vb=np.prod(np.maximum(b[3:]-b[:3],0.0)); return float(inter/max(va+vb-inter,1e-9))

def nms(preds,threshold,max_det):
    kept=[]
    for region in range(4):
        pool=sorted([p for p in preds if p['region_index']==region],key=lambda x:x['score'],reverse=True)
        while pool and len(kept)<max_det:
            best=pool.pop(0); kept.append(best); pool=[p for p in pool if iou3(np.asarray(best['box_xyz']),np.asarray(p['box_xyz']))<threshold]
    return sorted(kept,key=lambda x:x['score'],reverse=True)[:max_det]

def decode_patch(outputs,start_zyx,shape_dhw,volume_shape,topk,min_score):
    obj,reg,cls=outputs[0]; probability=torch.sigmoid(obj[0,0].float()); cp=F.softmax(cls[0].float(),dim=0); cprob,cidx=cp.max(0); score=probability*cprob
    k=min(int(topk),score.numel()); values,indices=torch.topk(score.flatten(),k); grid=np.asarray(score.shape); stride=np.asarray(shape_dhw)/grid; result=[]
    for val,flat in zip(values.detach().cpu().numpy(),indices.detach().cpu().numpy()):
        if float(val)<min_score: continue
        z=int(flat//(grid[1]*grid[2])); rem=int(flat%(grid[1]*grid[2])); y=rem//grid[2]; x=rem%grid[2]
        raw=reg[0,:,z,y,x].float(); offset=torch.sigmoid(raw[:3]).detach().cpu().numpy(); size_scale=np.exp(np.clip(raw[3:].detach().cpu().numpy(),-3,4))
        cell_xyz=np.asarray([x,y,z],float); stride_xyz=stride[::-1]; center_local=(cell_xyz+offset)*stride_xyz
        center_global=center_local+np.asarray(start_zyx[::-1]); extent=np.clip(size_scale*stride_xyz,2.0,80.0); box=np.r_[center_global-extent/2,center_global+extent/2]
        if np.any(center_global<0) or np.any(center_global>=np.asarray(volume_shape[::-1])): continue
        result.append({'score':float(val),'region_index':int(cidx[z,y,x]),'box_xyz':box.tolist()})
    return result

def lps(affine,xyz):
    return (np.asarray(affine)@np.r_[xyz,1.0])[:3]

def match_case(preds,gts,threshold,iou_threshold):
    used=set(); tp=0; fp=0; errors=[]
    for p in sorted([x for x in preds if x['score']>=threshold],key=lambda x:x['score'],reverse=True):
        candidates=[]
        for j,g in enumerate(gts):
            if j in used or g['region_index']!=p['region_index']: continue
            overlap=iou3(np.asarray(p['box_xyz']),np.asarray(g['box_xyz']))
            if overlap>=iou_threshold: candidates.append((overlap,j,g))
        if candidates:
            _,j,g=max(candidates); used.add(j); tp+=1; errors.append(float(np.linalg.norm(np.asarray(p['center_lps'])-np.asarray(g['center_lps']))))
        else: fp+=1
    return tp,fp,len(gts)-len(used),errors

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--project-root',type=Path,required=True); ap.add_argument('--config',type=Path,required=True); ap.add_argument('--checkpoint',type=Path,required=True); ap.add_argument('--normalization',type=Path,required=True); ap.add_argument('--output-dir',type=Path,required=True); args=ap.parse_args()
    root=args.project_root.resolve(); out=args.output_dir.resolve(); out.mkdir(parents=True,exist_ok=True); cfg=yaml.safe_load(args.config.read_text()); stats=json.loads(args.normalization.read_text())
    manifest=root/'manifests/inner_split_v1/nested_partitions_v1.csv'
    with open(manifest,newline='',encoding='utf-8') as f: rows=[r for r in csv.DictReader(f) if int(r['outer_test_fold'])==int(cfg['outer_fold']) and r['role']=='outer_test']
    if len(rows)!=17: raise RuntimeError(f'Expected 17 outer-test cases, found {len(rows)}')
    model=VRSSL3D().cuda().eval(); state=torch.load(args.checkpoint,map_location='cpu',weights_only=False); model.load_state_dict(state['teacher']); shape=list(map(int,cfg['patch_dhw'])); stride=list(map(int,cfg['stride_dhw'])); cache=root/'outputs/preprocessed_v1'
    all_cases=[]; csv_preds=[]; t0=time.time()
    with torch.no_grad():
        for ci,row in enumerate(rows,1):
            d=cache/row['device']/row['case_id']; v=np.load(d/'volume_resampled_float16.npy',mmap_mode='r'); meta=json.loads((d/'metadata.json').read_text())
            candidates=[]; count=0
            for z in starts(v.shape[0],shape[0],stride[0]):
                for y in starts(v.shape[1],shape[1],stride[1]):
                    for x in starts(v.shape[2],shape[2],stride[2]):
                        patch=norm(crop_at(v,(z,y,x),shape),stats); tensor=torch.from_numpy(patch[None,None]).float().cuda()
                        with torch.autocast('cuda',dtype=torch.float16): outputs,_=model(tensor,0.0)
                        candidates.extend(decode_patch(outputs,(z,y,x),shape,v.shape,int(cfg['per_patch_topk']),float(cfg['minimum_candidate_score']))); count+=1
            preds=nms(candidates,float(cfg['nms_iou']),int(cfg['maximum_detections_per_case'])); affine=np.asarray(meta['target_affine_xyz_to_lps'])
            for rank,p in enumerate(preds):
                box=np.asarray(p['box_xyz']); p['center_lps']=lps(affine,(box[:3]+box[3:])/2).tolist(); p['region_code']=f"R{p['region_index']+1:02d}"
                csv_preds.append({'device':row['device'],'case_id':row['case_id'],'rank':rank+1,'score':p['score'],'region_code':p['region_code'],'center_lps_x':p['center_lps'][0],'center_lps_y':p['center_lps'][1],'center_lps_z':p['center_lps'][2],'box_x1':box[0],'box_y1':box[1],'box_z1':box[2],'box_x2':box[3],'box_y2':box[4],'box_z2':box[5]})
            gts=[]
            for b in meta['boxes']:
                a=np.asarray(b['aabb_xyz_voxel']); gts.append({'box_xyz':a.tolist(),'center_lps':b['center_lps_mm'],'region_index':int(b['region_code'][1:])-1})
            all_cases.append({'device':row['device'],'case_id':row['case_id'],'windows':count,'predictions':preds,'ground_truth':gts}); print(f"[{ci:02d}/17] {row['device']}/{row['case_id']} windows={count} candidates={len(candidates)} kept={len(preds)} gt={len(gts)}",flush=True)
    thresholds=np.linspace(0,1,int(cfg['froc_thresholds'])); curve=[]; total_gt=sum(len(c['ground_truth']) for c in all_cases)
    for th in thresholds:
        tp=fp=fn=0; errors=[]
        for c in all_cases:
            a,b,d,e=match_case(c['predictions'],c['ground_truth'],float(th),float(cfg['matching_iou'])); tp+=a; fp+=b; fn+=d; errors+=e
        curve.append({'threshold':float(th),'sensitivity':tp/max(total_gt,1),'fp_per_volume':fp/len(all_cases),'tp':tp,'fp':fp,'fn':fn,'median_center_error_mm':float(np.median(errors)) if errors else None})
    eligible=[p for p in curve if p['fp_per_volume']<=1.0]; operating=max(eligible,key=lambda p:(p['sensitivity'],-p['fp_per_volume'])) if eligible else None
    report={'status':'PASS','version':cfg['version'],'pilot_exploratory_only':True,'outer_fold':cfg['outer_fold'],'test_cases':len(all_cases),'ground_truth_objects':total_gt,'checkpoint_sha256':digest(args.checkpoint),'normalization_sha256':digest(args.normalization),'elapsed_seconds':time.time()-t0,'exploratory_operating_point_le_1_fp_per_volume':operating,'froc_curve':curve,'note':'Threshold is exploratory on outer-test and must not be used as the final prespecified operating threshold.'}
    rp=out/'fold0_outer_test_metrics_v1.json'; rp.write_text(json.dumps(report,indent=2),encoding='utf-8')
    with (out/'fold0_outer_test_predictions_v1.csv').open('w',newline='',encoding='utf-8') as f:
        fields=list(csv_preds[0]) if csv_preds else ['device','case_id']; w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(csv_preds)
    files=[rp,out/'fold0_outer_test_predictions_v1.csv']; (out/'INFERENCE_SHA256SUMS.txt').write_text(''.join(f'{digest(p)}  {p.name}\n' for p in files),encoding='utf-8'); print(json.dumps({k:report[k] for k in ('status','test_cases','ground_truth_objects','elapsed_seconds','exploratory_operating_point_le_1_fp_per_volume')},indent=2)); print('FOLD-0 OUTER-TEST INFERENCE: PASS')

if __name__=='__main__': main()
